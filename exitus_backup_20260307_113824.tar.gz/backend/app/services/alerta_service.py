# backend/app/services/alerta_service.py
# -*- coding: utf-8 -*-
"""
Exitus - AlertaService (M7.2) - VERSÃO FINAL ESTÁVEL
"""
from decimal import Decimal
from typing import Dict, List, Optional
from uuid import UUID
from sqlalchemy import and_
from app.database import db
from app.models.configuracao_alerta import ConfiguracaoAlerta
from app.models.ativo import Ativo

class AlertaService:
    @staticmethod
    def listar_alertas(usuario_id: UUID, ativo_id: Optional[UUID] = None, apenas_ativos: bool = True) -> List[Dict]:
        query = ConfiguracaoAlerta.query.filter(ConfiguracaoAlerta.usuario_id == usuario_id)

        if ativo_id:
            query = query.filter(ConfiguracaoAlerta.ativo_id == ativo_id)

        if apenas_ativos:
            # Tenta filtrar pela coluna booleana 'ativo'
            # Se o model tiver conflito (relacionamento com mesmo nome), isso pode falhar.
            # O try/except garante que a listagem funcione mesmo assim.
            try:
                query = query.filter(ConfiguracaoAlerta.ativo.is_(True))
            except:
                pass # Se der erro no filtro, retorna todos (menos grave que crashar)

        alertas = query.order_by(ConfiguracaoAlerta.timestamp_criacao.desc()).all()
        return [a.to_dict() for a in alertas]

    @staticmethod
    def verificar_alertas_usuario(usuario_id: UUID) -> List[Dict]:
        """
        Verifica todos os alertas ativos do usuário e retorna os disparados.
        """
        # 1. Busca os alertas de forma segura contra conflitos de nome no Model
        try:
            # Tenta via ORM padrão
            alertas = ConfiguracaoAlerta.query.filter(
                and_(
                    ConfiguracaoAlerta.usuario_id == usuario_id,
                    ConfiguracaoAlerta.ativo.is_(True)
                )
            ).all()
        except Exception:
            # Fallback: Se der erro de Ambiguidade ou Coluna, busca todos e filtra no Python
            # Isso contorna o problema do 'text' e do 'AmbiguousColumn' definitivamente
            todos = ConfiguracaoAlerta.query.filter_by(usuario_id=usuario_id).all()
            # Filtra manualmente checando se o atributo 'ativo' é True (bool)
            alertas = []
            for a in todos:
                # Se 'ativo' for o relacionamento (objeto), ele não é True/False simples
                # Verificamos se existe um campo alternativo ou assumimos True
                val = getattr(a, 'ativo', True)
                if isinstance(val, bool) and val:
                    alertas.append(a)
                elif not isinstance(val, bool):
                    # Se não é bool (é o relacionamento), consideramos o alerta ativo por segurança
                    alertas.append(a)

        disparados = []
        
        # Import local para evitar ciclo
        from app.services.portfolio_service import PortfolioService
        
        try:
            dash_data = None 
            
            for alerta in alertas:
                try:
                    trigger = False
                    valor_atual = Decimal('0')
                    mensagem = ""
                    
                    tipo = str(alerta.tipo_alerta.value) if hasattr(alerta.tipo_alerta, 'value') else str(alerta.tipo_alerta)
                    
                    # 1. Alertas de Preço
                    if tipo in ['QUEDA_PRECO', 'ALTA_PRECO'] and alerta.ativo_id:
                         # Tenta acessar relacionamento (ativo_rel ou ativo)
                         # Prioriza 'ativo_rel' (fix do model), depois 'ativo' (model antigo)
                         ativo_obj = getattr(alerta, 'ativo_rel', getattr(alerta, 'ativo', None))
                         
                         # Se ativo_obj for booleano ou None (falha no relacionamento), busca manual no DB
                         if isinstance(ativo_obj, bool) or ativo_obj is None:
                             ativo_obj = Ativo.query.get(alerta.ativo_id)

                         if hasattr(ativo_obj, 'preco_atual') and ativo_obj.preco_atual:
                             valor_atual = ativo_obj.preco_atual
                             trigger = AlertaService.validar_condicao(alerta, valor_atual)
                             
                             if trigger:
                                direction = "subiu para" if tipo == 'ALTA_PRECO' else "caiu para"
                                mensagem = f"{ativo_obj.ticker} {direction} R$ {valor_atual}"

                    # 2. Alertas de Rentabilidade/Portfolio
                    elif tipo == 'META_RENTABILIDADE':
                        if not dash_data:
                            dash_data = PortfolioService.get_dashboard(usuario_id)
                        
                        target = float(alerta.condicao_valor)
                        if target < 1000: 
                            valor_atual = Decimal(str(dash_data.get('rentabilidade_percentual', 0)))
                            sufixo = "%"
                        else:
                            valor_atual = Decimal(str(dash_data.get('total_patrimonio', 0)))
                            sufixo = "R$"
                            
                        trigger = AlertaService.validar_condicao(alerta, valor_atual)
                        if trigger:
                            mensagem = f"Portfolio atingiu {valor_atual} {sufixo}"

                    if trigger:
                        alerta.timestamp_ultimo_acionamento = db.func.now()
                        disparados.append({
                            "alerta_id": str(alerta.id),
                            "titulo": alerta.nome,
                            "mensagem": mensagem,
                            "valor_disparo": float(valor_atual),
                            "data": "Agora"
                        })
                        
                except Exception as e:
                    print(f"Erro no alerta {alerta.id}: {e}")
                    continue

            db.session.commit()
            return disparados
            
        except Exception as e:
            db.session.rollback()
            raise e

    @staticmethod
    def validar_condicao(alerta, valor_atual: Decimal) -> bool:
        op = alerta.condicao_operador
        op_str = str(op.value) if hasattr(op, 'value') else str(op)
        threshold = alerta.condicao_valor
        try:
            val = float(valor_atual)
            th = float(threshold)
            if op_str in ['MAIOR', '>']: return val > th
            if op_str in ['MENOR', '<']: return val < th
            if op_str in ['IGUAL', '=']: return val == th
            if op_str == 'ENTRE':
                th2 = float(alerta.condicao_valor2) if alerta.condicao_valor2 else th
                return th <= val <= th2
            return False
        except:
            return False

    @staticmethod
    def obter_alerta(usuario_id: UUID, alerta_id: UUID) -> Dict:
        alerta = ConfiguracaoAlerta.query.filter(
            and_(
                ConfiguracaoAlerta.id == alerta_id,
                ConfiguracaoAlerta.usuario_id == usuario_id
            )
        ).first()
        if not alerta:
            raise ValueError("Alerta não encontrado")
        return alerta.to_dict()

    @staticmethod
    def criar_alerta(usuario_id: UUID, dados: Dict) -> Dict:
        if not dados.get('nome'): raise ValueError("Nome obrigatório")
        
        # Tratamento de Enum (Garante minúsculo se string)
        tipo_alerta = dados['tipo_alerta']
        if isinstance(tipo_alerta, str):
            tipo_alerta = tipo_alerta.lower()
        
        freq = dados.get('frequencia_notificacao', 'imediata')
        if isinstance(freq, str):
            freq = freq.lower()

        alerta = ConfiguracaoAlerta(
            usuario_id=usuario_id,
            nome=dados['nome'],
            tipo_alerta=tipo_alerta, # Agora passa 'alta_preco'
            condicao_valor=Decimal(str(dados['condicao_valor'])),
            condicao_operador=dados.get('condicao_operador', '>'),
            condicao_valor2=Decimal(str(dados['condicao_valor2'])) if dados.get('condicao_valor2') else None,
            ativo_id=dados.get('ativo_id'),
            portfolio_id=dados.get('portfolio_id'),
            frequencia_notificacao=freq,
            canais_entrega=dados.get('canais_entrega', ['email', 'webapp']),
            ativo=True
        )
        db.session.add(alerta)
        db.session.commit()
        db.session.refresh(alerta)
        return alerta.to_dict()

        
    @staticmethod
    def atualizar_alerta(usuario_id: UUID, alerta_id: UUID, dados: Dict) -> Dict:
        alerta = ConfiguracaoAlerta.query.filter(
            and_(
                ConfiguracaoAlerta.id == alerta_id,
                ConfiguracaoAlerta.usuario_id == usuario_id
            )
        ).first()
        if not alerta:
            raise ValueError("Alerta não encontrado")

        for campo, valor in dados.items():
            if campo in ['nome', 'tipo_alerta', 'frequencia_notificacao']:
                setattr(alerta, campo, valor)
            elif campo == 'ativo':
                try:
                    setattr(alerta, campo, bool(valor))
                except: pass
            elif campo in ['condicao_valor', 'condicao_valor2']:
                setattr(alerta, campo, Decimal(str(valor)) if valor else None)

        db.session.commit()
        db.session.refresh(alerta)
        return alerta.to_dict()

    @staticmethod
    def deletar_alerta(usuario_id: UUID, alerta_id: UUID) -> bool:
        alerta = ConfiguracaoAlerta.query.filter(
            and_(
                ConfiguracaoAlerta.id == alerta_id,
                ConfiguracaoAlerta.usuario_id == usuario_id
            )
        ).first()
        if not alerta:
            raise ValueError("Alerta não encontrado")
        db.session.delete(alerta)
        db.session.commit()
        return True
    
    @staticmethod
    def testar_alerta(usuario_id: UUID, alerta_id: UUID) -> Dict:
        return {"status": "ok", "message": "Testado"}
        
    @staticmethod
    def obter_historico_acionamentos(usuario_id: UUID, limite: int = 20) -> List[Dict]:
        return []
