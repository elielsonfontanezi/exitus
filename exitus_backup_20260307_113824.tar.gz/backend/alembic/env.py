from logging.config import fileConfig
from sqlalchemy import engine_from_config
from sqlalchemy import pool
from alembic import context

# Adicionar path do app
import sys
import os
sys.path.insert(0, os.path.realpath(os.path.join(os.path.dirname(__file__), '..')))

# Importar a aplicação Flask e o db
from app import create_app
from app.database import db

# this is the Alembic Config object
config = context.config

# Interpret the config file for Python logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Criar aplicação Flask e obter metadata
app = create_app()
with app.app_context():
    # Garantir que todos os models sejam importados
    from app.models import (
        Usuario, Corretora, Ativo, Posicao, Transacao,
        Provento, MovimentacaoCaixa, EventoCorporativo,
        FonteDados, RegraFiscal, FeriadoMercado, LogAuditoria,
        SaldoPrejuizo,
    )
    target_metadata = db.metadata
    
# Configurar URL do banco
config.set_main_option('sqlalchemy.url', app.config['SQLALCHEMY_DATABASE_URI'])


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
