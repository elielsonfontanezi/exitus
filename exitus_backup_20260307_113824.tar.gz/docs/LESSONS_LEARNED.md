# Lições Aprendidas — Sistema Exitus

> **Propósito:** Regras ativas derivadas de erros reais em produção/desenvolvimento.  
> Consultado pela IA **antes de qualquer ação** para evitar repetição de erros.  
> **Atualizado:** 05/03/2026 — L-DB-004 corrigido (ENUM-001 concluído)  
> **Ver também:** `docs/CODING_STANDARDS.md`, `.codeium.rules`

---

## 🗄️ Banco de Dados

### L-DB-001 — Usar DELETE, nunca DROP, para reset de dados
**Origem:** EXITUS-SEED-001 | **Data:** 02/03/2026

```python
# ❌ ERRADO — perde schema, constraints, índices, migrations
db.drop_all()
db.create_all()

# ✅ CORRETO — limpa dados, preserva estrutura
db.session.execute(text("DELETE FROM tabela"))
```
**Regra:** "O que preciso resetar?" → Dados = DELETE. Schema = DROP (raramente).  
**PKs são UUID** neste sistema — não existem sequences para resetar.

---

### L-DB-002 — Nunca deduzir nomes de tabelas — sempre consultar
**Origem:** EXITUS-SEED-001 | **Data:** 02/03/2026

```python
# ❌ ERRADO — 'movimentacao' não existe; é 'movimentacao_caixa'
tables = ['movimentacao', 'transacao', ...]

# ✅ CORRETO — listar do banco
from sqlalchemy import inspect
print(sorted(inspect(db.engine).get_table_names()))
# ou: podman exec exitus-db psql -U exitus -d exitusdb -c "\dt"
```
**Tabelas reais (22):** `ativo`, `alertas`, `auditoria_relatorios`, `configuracoes_alertas`,
`corretora`, `evento_corporativo`, `evento_custodia`, `feriado_mercado`, `fonte_dados`,
`historico_preco`, `log_auditoria`, `movimentacao_caixa`, `parametros_macro`, `portfolio`,
`posicao`, `projecoes_renda`, `provento`, `regra_fiscal`, `relatorios_performance`,
`transacao`, `usuario`, `alembic_version`.

---

### L-DB-003 — PKs são UUID v4 — não existem sequences
**Origem:** EXITUS-SEED-001 | **Data:** 02/03/2026

Todos os models usam `id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)`.  
Não há sequences no schema. `ALTER SEQUENCE ... RESTART` vai falhar.

---

### L-DB-004 — ENUMs PostgreSQL devem ser lowercase (resolvido)
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026 | **Resolvido:** 04/03/2026

| ENUM | No PostgreSQL | No Python (model) | Status |
|------|--------------|-------------------|--------|
| Todos os 12 ENUMs | lowercase | lowercase | ✅ normalizado |

**✅ Fix aplicado:** EXITUS-ENUM-001 (04/03/2026) — migration normalizou todos os 12 ENUMs para lowercase. `values_callable` obrigatório em todos os models (verificado por `test_model_standards.py`).

**Regra ativa:** Sempre usar `values_callable=lambda x: [e.value for e in x]` e `create_type=False` em colunas ENUM. Ver `CODING_STANDARDS.md`.

---

### L-DB-005 — Banco de teste deve ser criado via pg_dump, não via migrations
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

A cadeia de migrations Alembic **não consegue criar um banco do zero** de forma confiável
(inconsistências acumuladas de ENUM case, migrations quebradas, dependências circulares).

```bash
# ✅ Forma correta de criar/recriar exitusdb_test
podman exec exitus-db pg_dump -U exitus -d exitusdb --schema-only --no-owner --no-acl \
  | podman exec -i exitus-db psql -U exitus -d exitusdb_test
```

**Fix planejado:** Script automatizado EXITUS-TESTDB-001.

---

## 🔧 Alembic / Migrations

### L-MIG-001 — Toda migration criada manualmente precisa das 4 variáveis no corpo
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```python
# ❌ ERRADO — Alembic não lê do docstring
"""Revision ID: 9e4ef61dee5d ..."""

# ✅ CORRETO — variáveis obrigatórias no corpo do módulo
revision = '9e4ef61dee5d'
down_revision = '202602162130'  # ou None para a primeira
branch_labels = None
depends_on = None
```

---

### L-MIG-002 — ENUMs em migrations devem ser idempotentes
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```python
# ❌ ERRADO — falha com DuplicateObject se ENUM já existe
postgresql.ENUM('a', 'b', name='meuenum', create_type=True).create(op.get_bind())

# ✅ CORRETO — idempotente
op.execute("""
    DO $$ BEGIN
        CREATE TYPE meuenum AS ENUM ('a', 'b');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$
""")
```

Ao referenciar o tipo na coluna, usar `create_type=False`:
```python
sa.Column('campo', postgresql.ENUM(name='meuenum', create_type=False))
```

---

## 🐍 SQLAlchemy + Flask

### L-SA-001 — Imports locais em funções impedem mocking em testes
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```python
# ❌ ERRADO — patch('app.utils.business_rules.Posicao') falha
def validar_saldo(usuario_id):
    from app.models.posicao import Posicao  # não fica no namespace do módulo
    ...

# ✅ CORRETO — import no topo, mockável normalmente
from app.models.posicao import Posicao

def validar_saldo(usuario_id):
    ...
```

**Regra:** Imports de models em `utils/` e `services/` devem estar no **topo do arquivo**.
Exceção aceita apenas para imports circulares comprovados e documentados.

---

### L-SA-002 — session.configure(bind=connection) é incompatível com Flask test_client
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```python
# ❌ NÃO FUNCIONA — Flask test_client abre conexões próprias do pool
connection = db.engine.connect()
db.session.configure(bind=connection)
yield db
connection.rollback()  # não desfaz commits feitos via HTTP request

# ✅ CORRETO — app context session-scoped + DELETE no teardown
@pytest.fixture(scope='session')
def app():
    ctx = application.app_context()
    ctx.push()
    yield application
    ctx.pop()

@pytest.fixture(scope='function')
def auth_client(app):
    u = Usuario(...)
    db.session.add(u)
    db.session.commit()
    yield client
    Usuario.query.filter_by(username=u.username).delete()
    db.session.commit()
```

---

### L-SA-003 — Múltiplos app_context() aninhados causam "Popped wrong app context"
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

Com `app` fixture de escopo `session` que já mantém um contexto ativo via `ctx.push()`,
fixtures de escopo `function` **não devem** abrir `with app.app_context()`.
Operam diretamente no contexto já ativo.

---

### L-SA-004 — `Query.get()` está depreciado no SQLAlchemy 2.x — 27 ocorrências no codebase
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```python
# ❌ DEPRECIADO — SQLAlchemy 2.x emite warning; será removido
ativo = Ativo.query.get(ativo_id)

# ✅ CORRETO — SQLAlchemy 2.x
ativo = db.session.get(Ativo, ativo_id)
```

Afeta 11 arquivos: `ativo_service.py`, `usuario_service.py`, `corretora_service.py`,
`provento_service.py`, `transacao_service.py`, `feriado_mercado_service.py`,
`regra_fiscal_service.py`, `evento_corporativo_service.py`, `historico_service.py`,
`alerta_service.py`, `decorators.py`, `auth/routes.py`.  
**Fix planejado:** EXITUS-SQLALCHEMY-002.

---

## 🌐 Contrato da API

### L-API-001 — Endpoint de listagem usa envelope de paginação aninhado
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

```json
// ✅ Endpoints de entidade única (padrão)
{ "success": true, "data": { "id": "...", "ticker": "PETR4" } }

// ⚠️  Endpoints de listagem com paginação (diferente!)
{ "success": true, "data": { "ativos": [...], "total": 65, "pages": 4, "page": 1, "per_page": 20 } }
```

Em testes e no frontend, extrair a lista com:
```python
inner = data.get('data', {})
lista = inner.get('ativos', []) if isinstance(inner, dict) else inner
```

---

### L-API-002 — Flask-JWT-Extended retorna 422 para token malformado, não 401
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

- **401** → token ausente ou expirado
- **422** → token presente mas malformado/inválido

```python
# ✅ Testes devem aceitar ambos
assert response.status_code in (401, 422)
```

---

### L-API-003 — Ticker tem validação restritiva (sem underscore)
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

O endpoint `POST /api/ativos/` aceita apenas letras, números, pontos e hífens.
Underscore (`_`) retorna 400. Em testes, usar sufixos numéricos: `f'TST{uuid4().int[:4]}'`.

---

## 🏗️ Models

### L-MOD-001 — Regra de negócio coerente ≠ campo existente no model
**Origem:** EXITUS-SEED-001 | **Data:** 02/03/2026

```python
# ❌ ERRADO — 'pais' faz sentido no domínio mas não existe em Ativo
ativo = Ativo(ticker='PETR4', pais='BR')

# ✅ CORRETO — Ativo usa 'mercado' para indicar região
ativo = Ativo(ticker='PETR4', mercado='BR')
```

**Regra:** Sempre ler o arquivo `models/nome_model.py` e verificar as `Column(...)` definidas
antes de usar um campo. Nunca assumir campos por analogia com outros models.

---

### L-API-004 — `ValueError` usado para 404 E 400 — contrato de exceções ambíguo
**Origem:** EXITUS-TESTS-001 | **Data:** 03/03/2026

Os services lançam `ValueError` para **dois significados distintos**:

```python
# ❌ AMBÍGUO — route não sabe se é 404 ou 400
raise ValueError("Ativo não encontrado")    # deveria ser 404
raise ValueError("Ticker já existe")        # deveria ser 400
```

O route captura tudo como 400:
```python
except ValueError as e:
    return error(str(e), 400)  # ← engloba casos de 404 incorretamente
```

**Padrão correto (a implementar em EXITUS-CRUD-002):**
```python
# No service — exceções tipadas
class NotFoundError(Exception): pass
class ConflictError(Exception): pass

raise NotFoundError("Ativo não encontrado")  # → 404
raise ConflictError("Ticker já existe")      # → 409

# No route — mapeamento semântico
except NotFoundError as e:
    return not_found(str(e))      # 404
except ConflictError as e:
    return error(str(e), 409)     # 409
except ValidationError as e:
    return error(str(e), 400)     # 400
```

**Fix planejado:** EXITUS-CRUD-002.

---

### L-TEST-001 — Nunca usar dados hardcoded em testes de integração
**Origem:** EXITUS-TESTDB-001 | **Data:** 03/03/2026

Testes com usernames, tickers ou valores fixos (`'test_admin'`, `'PETR4'`, `38.50`) passam enquanto o banco de teste tem esses dados herdados do banco de produção. Ao zerar o banco (ex: via `create_test_db.sh`), os testes quebram silenciosamente.

```python
# ❌ ERRADO — depende de dado pré-existente no banco
response = client.get('/api/ativos/ticker/PETR4')
assert data['data']['ticker'] == 'PETR4'

# ✅ CORRETO — dado dinâmico criado e destruído pela própria fixture
def test_ticker_existente(auth_client, ativo_seed):
    response = client.get(f'/api/ativos/ticker/{ativo_seed.ticker}')
    assert data['data']['ticker'] == ativo_seed.ticker
```

**Regra:** Toda fixture de entidade deve ser criada no `conftest.py` com sufixo UUID e destruída no teardown. Nenhum teste deve depender de dados que existam apenas no banco de produção.

---

### L-TEST-002 — `db.create_all()` falha com ENUMs PostgreSQL nativos
**Origem:** EXITUS-TESTDB-001 | **Data:** 03/03/2026

`db.create_all()` tenta criar tabelas com CHECK constraints que referenciam valores de ENUMs (`'split'`, `'grupamento'`) antes de criar o tipo ENUM no PostgreSQL, causando `InvalidTextRepresentation`.

```python
# ❌ ERRADO — não respeita ordem de criação de tipos ENUM PostgreSQL
with app.app_context():
    db.create_all()  # DataError: invalid input value for enum tipoeventocorporativo

# ✅ CORRETO — pg_dump garante ordem correta (ENUMs antes das tabelas)
podman exec exitus-db pg_dump -U exitus --schema-only --no-owner exitusdb | \
    podman exec -i exitus-db psql -U exitus -d exitusdb_test
```

**Regra:** Para recriar o banco de teste, usar sempre `pg_dump --schema-only` do banco de produção via `scripts/create_test_db.sh`. Nunca usar `db.create_all()` para setup de banco de teste em projetos com ENUMs PostgreSQL nativos.

---

### L-TEST-003 — `DetachedInstanceError` em teardown de testes — salvar IDs antes de sair do contexto
**Origem:** EXITUS-IR-005 | **Data:** 04/03/2026

```python
# ❌ ERRADO — objeto fica detached ao sair do with app.app_context()
with app.app_context():
    resgate = Transacao(...)
    db.session.commit()
try:
    ...
finally:
    Transacao.query.filter_by(id=resgate.id).delete()  # DetachedInstanceError!

# ✅ CORRETO — salvar IDs escalares antes de sair do contexto
with app.app_context():
    resgate = Transacao(...)
    db.session.commit()
    resgate_id = resgate.id   # UUID copiado enquanto session está ativa
try:
    ...
finally:
    Transacao.query.filter_by(id=resgate_id).delete()  # ID escalar, sem detach
    db.session.commit()
```

**Regra:** Em testes `function`-scoped com `app` fixture `session`-scoped, objetos SQLAlchemy
não devem ser acessados fora do bloco que os criou. Copiar sempre `.id` (e outros escalares
necessitários) antes de fechar o `with app.app_context()` ou antes do `commit` final.

---

### L-TEST-004 — Usar `decode_token` para obter `usuario_id` do `auth_client` em fixtures
**Origem:** EXITUS-IR-005 | **Data:** 04/03/2026

```python
# ❌ ERRADO — busca um usuário aleatório do banco (pode não ser o do token JWT)
from app.models.usuario import Usuario
u = Usuario.query.filter(Usuario.username.like('ta%')).first()
# Cria dados vinculados a u.id, mas auth_client tem token de outro usuário

# ✅ CORRETO — extrair usuario_id diretamente do token JWT do auth_client
from flask_jwt_extended import decode_token
token = auth_client._auth_headers['Authorization'].split(' ')[1]
with app.app_context():
    decoded = decode_token(token)
usuario_id = decoded['sub']  # UUID do usuário que o endpoint irá usar
```

**Regra:** Em testes que criam dados de setup e chamam endpoints autenticados via `auth_client`,
os dados devem ser criados com o `usuario_id` extraido do token — nunca via query heurística
no banco. Isso garante que a apuração encontre exatamente os dados criados pelo teste.

---

## 📋 Referências

| Documento | Papel |
|---|---|
| `docs/CODING_STANDARDS.md` | Padrões de código para humanos |
| `docs/ROADMAP.md` | GAPs registrados (ENUM-001, TESTDB-001) |
| `.windsurfrules` | Regras operacionais do Cascade (Windsurf) |
| `docs/EXITUS-SQLALCHEMY-001.md` | Padrões SQLAlchemy detalhados |
