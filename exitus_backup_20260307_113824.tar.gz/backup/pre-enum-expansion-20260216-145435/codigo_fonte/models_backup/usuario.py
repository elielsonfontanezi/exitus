# -*- coding: utf-8 -*-
"""Exitus - Model Usuario - Entidade principal para autenticação"""

import enum
from datetime import datetime
from sqlalchemy import String, Boolean, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
from app.database import db

class UserRole(enum.Enum):
    """Enum para roles/perfis de usuário"""
    ADMIN = "admin"
    USER = "user"
    READONLY = "readonly"

class Usuario(db.Model):
    """Model para usuários do sistema Exitus"""
    __tablename__ = 'usuario'  # ⬅️ PLURAL (consistente com FK)

    # Identificação
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = db.Column(String(50), unique=True, nullable=False, index=True)
    email = db.Column(String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(String(255), nullable=False)
    nome_completo = db.Column(String(200), nullable=True)

    # Controle
    ativo = db.Column(Boolean, default=True, nullable=False)
    role = db.Column(Enum(UserRole), default=UserRole.USER, nullable=False)

    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    updated_at = db.Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relacionamentos
    # 'Portfolio' como string para evitar Import Circular
    portfolios = relationship('Portfolio', back_populates='usuario', lazy='dynamic', cascade='all, delete-orphan')

    def set_password(self, password):
        """Define a senha do usuário (gera hash bcrypt)"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Verifica se a senha fornecida está correta"""
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        """Verifica se usuário é administrador"""
        return self.role == UserRole.ADMIN

    def is_active(self):
        """Verifica se usuário está ativo"""
        return self.ativo

    def to_dict(self, include_sensitive=False):
        """Converte objeto para dicionário para serialização JSON"""
        data = {
            "id": str(self.id),
            "username": self.username,
            "email": self.email,
            "nome_completo": self.nome_completo,
            "ativo": self.ativo,
            "role": self.role.value if self.role else UserRole.USER.value,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

        if include_sensitive:
            data["password_hash"] = self.password_hash

        return data

    def __repr__(self):
        """Representação string do objeto"""
        return f"<Usuario {self.username} ({self.email})>"
