--
-- PostgreSQL database dump
--

\restrict yJrdMaalVNGLlAnGpPFtoVAB9G9pBU4MbtcNfQ3Pkhvb18K2YglZjBuiENJzCiC

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: classeativo; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.classeativo AS ENUM (
    'RENDA_VARIAVEL',
    'RENDA_FIXA',
    'CRIPTO',
    'HIBRIDO'
);


ALTER TYPE public.classeativo OWNER TO exitus;

--
-- Name: formatoexport; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.formatoexport AS ENUM (
    'visualizacao',
    'pdf',
    'excel'
);


ALTER TYPE public.formatoexport OWNER TO exitus;

--
-- Name: frequencianotificacao; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.frequencianotificacao AS ENUM (
    'imediata',
    'diaria',
    'semanal',
    'mensal'
);


ALTER TYPE public.frequencianotificacao OWNER TO exitus;

--
-- Name: incidenciaimposto; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.incidenciaimposto AS ENUM (
    'LUCRO',
    'RECEITA',
    'PROVENTO',
    'OPERACAO'
);


ALTER TYPE public.incidenciaimposto OWNER TO exitus;

--
-- Name: operadorcondicao; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.operadorcondicao AS ENUM (
    '>',
    '<',
    '==',
    '>=',
    '<=',
    'ENTRE'
);


ALTER TYPE public.operadorcondicao OWNER TO exitus;

--
-- Name: tipoalerta; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipoalerta AS ENUM (
    'queda_preco',
    'alta_preco',
    'dividendo_previsto',
    'meta_rentabilidade',
    'volatilidade_alta',
    'desvio_alocacao',
    'noticias_ativo'
);


ALTER TYPE public.tipoalerta OWNER TO exitus;

--
-- Name: tipoativo; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipoativo AS ENUM (
    'ACAO',
    'FII',
    'REIT',
    'BOND',
    'ETF',
    'CRIPTO',
    'OUTRO'
);


ALTER TYPE public.tipoativo OWNER TO exitus;

--
-- Name: tipocorretora; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipocorretora AS ENUM (
    'CORRETORA',
    'EXCHANGE'
);


ALTER TYPE public.tipocorretora OWNER TO exitus;

--
-- Name: tipoeventocorporativo; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipoeventocorporativo AS ENUM (
    'SPLIT',
    'GRUPAMENTO',
    'BONIFICACAO',
    'DIREITO_SUBSCRICAO',
    'FUSAO',
    'CISAO',
    'INCORPORACAO',
    'MUDANCA_TICKER',
    'DESLISTAGEM',
    'RELISTING',
    'CANCELAMENTO',
    'OUTRO'
);


ALTER TYPE public.tipoeventocorporativo OWNER TO exitus;

--
-- Name: tipoferiado; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipoferiado AS ENUM (
    'NACIONAL',
    'BOLSA',
    'PONTE',
    'FECHAMENTO_ANTECIPADO',
    'MANUTENCAO',
    'OUTRO'
);


ALTER TYPE public.tipoferiado OWNER TO exitus;

--
-- Name: tipofontedados; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipofontedados AS ENUM (
    'API',
    'SCRAPER',
    'MANUAL',
    'ARQUIVO',
    'OUTRO'
);


ALTER TYPE public.tipofontedados OWNER TO exitus;

--
-- Name: tipomovimentacao; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipomovimentacao AS ENUM (
    'DEPOSITO',
    'SAQUE',
    'TRANSFERENCIA_ENVIADA',
    'TRANSFERENCIA_RECEBIDA',
    'CREDITO_PROVENTO',
    'PAGAMENTO_TAXA',
    'PAGAMENTO_IMPOSTO',
    'AJUSTE',
    'OUTRO'
);


ALTER TYPE public.tipomovimentacao OWNER TO exitus;

--
-- Name: tipooperacao; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipooperacao AS ENUM (
    'COMPRA',
    'VENDA'
);


ALTER TYPE public.tipooperacao OWNER TO exitus;

--
-- Name: tipoprovento; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipoprovento AS ENUM (
    'DIVIDENDO',
    'JCP',
    'RENDIMENTO',
    'CUPOM',
    'BONIFICACAO',
    'DIREITO_SUBSCRICAO',
    'OUTRO'
);


ALTER TYPE public.tipoprovento OWNER TO exitus;

--
-- Name: tiporelatorio; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tiporelatorio AS ENUM (
    'portfolio',
    'performance',
    'renda_passiva',
    'investimento',
    'customizado'
);


ALTER TYPE public.tiporelatorio OWNER TO exitus;

--
-- Name: tipotransacao; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.tipotransacao AS ENUM (
    'COMPRA',
    'VENDA',
    'DIVIDENDO',
    'JCP',
    'BONIFICACAO',
    'DESDOBRAMENTO',
    'GRUPAMENTO'
);


ALTER TYPE public.tipotransacao OWNER TO exitus;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: exitus
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'USER',
    'READONLY'
);


ALTER TYPE public.userrole OWNER TO exitus;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO exitus;

--
-- Name: ativo; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.ativo (
    id uuid NOT NULL,
    ticker character varying(20) NOT NULL,
    nome character varying(200) NOT NULL,
    tipo public.tipoativo NOT NULL,
    classe public.classeativo NOT NULL,
    mercado character varying(10) NOT NULL,
    moeda character varying(3) NOT NULL,
    preco_atual numeric(18,6),
    data_ultima_cotacao timestamp with time zone,
    dividend_yield numeric(8,4),
    p_l numeric(10,2),
    p_vp numeric(10,2),
    roe numeric(8,4),
    ativo boolean NOT NULL,
    deslistado boolean NOT NULL,
    data_deslistagem date,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preco_teto numeric(18,6),
    beta numeric(8,4),
    CONSTRAINT ativo_nome_min_length CHECK ((length((nome)::text) >= 2)),
    CONSTRAINT ativo_preco_positivo CHECK (((preco_atual IS NULL) OR (preco_atual >= (0)::numeric))),
    CONSTRAINT ativo_ticker_min_length CHECK ((length((ticker)::text) >= 1))
);


ALTER TABLE public.ativo OWNER TO exitus;

--
-- Name: TABLE ativo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.ativo IS 'Tabela de ativos financeiros (ações, FIIs, REITs, bonds, criptomoedas)';


--
-- Name: COLUMN ativo.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.id IS 'Identificador único do ativo';


--
-- Name: COLUMN ativo.ticker; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.ticker IS 'Código/símbolo do ativo (ex: PETR4, AAPL, BTC)';


--
-- Name: COLUMN ativo.nome; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.nome IS 'Nome completo do ativo';


--
-- Name: COLUMN ativo.tipo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.tipo IS 'Tipo do ativo (ação, FII, REIT, bond, cripto)';


--
-- Name: COLUMN ativo.classe; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.classe IS 'Classe do ativo (renda variável, fixa, cripto)';


--
-- Name: COLUMN ativo.mercado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.mercado IS 'Mercado/país de negociação (BR, US, EUR)';


--
-- Name: COLUMN ativo.moeda; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.moeda IS 'Moeda de negociação (BRL, USD, EUR)';


--
-- Name: COLUMN ativo.preco_atual; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.preco_atual IS 'Preço/cotação atual do ativo';


--
-- Name: COLUMN ativo.data_ultima_cotacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.data_ultima_cotacao IS 'Data e hora da última cotação';


--
-- Name: COLUMN ativo.dividend_yield; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.dividend_yield IS 'Dividend Yield em % (ex: 6.5000 = 6.5%)';


--
-- Name: COLUMN ativo.p_l; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.p_l IS 'Índice Preço/Lucro';


--
-- Name: COLUMN ativo.p_vp; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.p_vp IS 'Índice Preço/Valor Patrimonial';


--
-- Name: COLUMN ativo.roe; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.roe IS 'Return on Equity em %';


--
-- Name: COLUMN ativo.ativo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.ativo IS 'Indica se ativo está disponível para negociação';


--
-- Name: COLUMN ativo.deslistado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.deslistado IS 'Indica se ativo foi deslistado da bolsa';


--
-- Name: COLUMN ativo.data_deslistagem; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.data_deslistagem IS 'Data de deslistagem (se aplicável)';


--
-- Name: COLUMN ativo.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.observacoes IS 'Observações e notas sobre o ativo';


--
-- Name: COLUMN ativo.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN ativo.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.ativo.updated_at IS 'Data da última atualização';


--
-- Name: auditoria_relatorios; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.auditoria_relatorios (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    tipo_relatorio public.tiporelatorio NOT NULL,
    data_inicio date,
    data_fim date,
    filtros json,
    resultado_json json,
    timestamp_criacao timestamp with time zone DEFAULT now() NOT NULL,
    timestamp_download timestamp with time zone,
    formato_export public.formatoexport DEFAULT 'visualizacao'::public.formatoexport NOT NULL,
    chave_api_auditoria character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT auditoria_relatorio_datas_validas CHECK (((data_inicio IS NULL) OR (data_fim IS NULL) OR (data_inicio <= data_fim)))
);


ALTER TABLE public.auditoria_relatorios OWNER TO exitus;

--
-- Name: configuracoes_alertas; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.configuracoes_alertas (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    ativo_id uuid,
    portfolio_id uuid,
    nome character varying(200) NOT NULL,
    tipo_alerta public.tipoalerta NOT NULL,
    condicao_valor numeric(18,6) NOT NULL,
    condicao_operador public.operadorcondicao DEFAULT '>'::public.operadorcondicao NOT NULL,
    condicao_valor2 numeric(18,6),
    ativo boolean DEFAULT true NOT NULL,
    frequencia_notificacao public.frequencianotificacao DEFAULT 'imediata'::public.frequencianotificacao NOT NULL,
    canais_entrega character varying[] DEFAULT '{email,webapp}'::character varying[] NOT NULL,
    timestamp_criacao timestamp with time zone DEFAULT now() NOT NULL,
    timestamp_ultimo_acionamento timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alerta_entre_requer_valor2 CHECK (((condicao_operador <> 'ENTRE'::public.operadorcondicao) OR (condicao_valor2 IS NOT NULL))),
    CONSTRAINT alerta_valor2_apenas_entre CHECK (((condicao_operador = 'ENTRE'::public.operadorcondicao) OR (condicao_valor2 IS NULL)))
);


ALTER TABLE public.configuracoes_alertas OWNER TO exitus;

--
-- Name: corretora; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.corretora (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    nome character varying(100) NOT NULL,
    tipo public.tipocorretora NOT NULL,
    pais character varying(2) NOT NULL,
    moeda_padrao character varying(3) NOT NULL,
    saldo_atual numeric(18,2) NOT NULL,
    ativa boolean NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT corretora_moeda_iso_format CHECK (((moeda_padrao)::text ~* '^[A-Z]{3}$'::text)),
    CONSTRAINT corretora_nome_min_length CHECK ((length((nome)::text) >= 2)),
    CONSTRAINT corretora_pais_iso_format CHECK (((pais)::text ~* '^[A-Z]{2}$'::text)),
    CONSTRAINT corretora_saldo_positivo CHECK ((saldo_atual >= (0)::numeric))
);


ALTER TABLE public.corretora OWNER TO exitus;

--
-- Name: TABLE corretora; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.corretora IS 'Tabela de corretoras e contas de investimento';


--
-- Name: COLUMN corretora.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.id IS 'Identificador único da corretora';


--
-- Name: COLUMN corretora.usuario_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.usuario_id IS 'ID do usuário proprietário';


--
-- Name: COLUMN corretora.nome; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.nome IS 'Nome da corretora/exchange (ex: XP, Clear, Binance)';


--
-- Name: COLUMN corretora.tipo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.tipo IS 'Tipo: corretora tradicional ou exchange cripto';


--
-- Name: COLUMN corretora.pais; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.pais IS 'Código ISO 3166-1 alpha-2 do país (BR, US, etc.)';


--
-- Name: COLUMN corretora.moeda_padrao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.moeda_padrao IS 'Código ISO 4217 da moeda (BRL, USD, EUR)';


--
-- Name: COLUMN corretora.saldo_atual; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.saldo_atual IS 'Saldo disponível em caixa (na moeda padrão)';


--
-- Name: COLUMN corretora.ativa; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.ativa IS 'Indica se conta está ativa';


--
-- Name: COLUMN corretora.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.observacoes IS 'Observações e notas do usuário sobre a conta';


--
-- Name: COLUMN corretora.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN corretora.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.corretora.updated_at IS 'Data da última atualização';


--
-- Name: evento_corporativo; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.evento_corporativo (
    id uuid NOT NULL,
    ativo_id uuid NOT NULL,
    ativo_novo_id uuid,
    tipo_evento public.tipoeventocorporativo NOT NULL,
    data_evento date NOT NULL,
    data_com date,
    proporcao character varying(20),
    descricao text NOT NULL,
    impacto_posicoes boolean NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT evento_data_com_valida CHECK (((data_com IS NULL) OR (data_com <= data_evento)))
);


ALTER TABLE public.evento_corporativo OWNER TO exitus;

--
-- Name: TABLE evento_corporativo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.evento_corporativo IS 'Tabela de eventos corporativos que afetam ativos';


--
-- Name: COLUMN evento_corporativo.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.id IS 'Identificador único do evento';


--
-- Name: COLUMN evento_corporativo.ativo_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.ativo_id IS 'ID do ativo afetado pelo evento';


--
-- Name: COLUMN evento_corporativo.ativo_novo_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.ativo_novo_id IS 'ID do novo ativo (fusões, mudanças de ticker)';


--
-- Name: COLUMN evento_corporativo.tipo_evento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.tipo_evento IS 'Tipo do evento corporativo';


--
-- Name: COLUMN evento_corporativo.data_evento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.data_evento IS 'Data do evento';


--
-- Name: COLUMN evento_corporativo.data_com; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.data_com IS 'Data COM (último dia para ter direito ao evento)';


--
-- Name: COLUMN evento_corporativo.proporcao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.proporcao IS 'Proporção do evento (ex: ''2:1'', ''1:10'', ''1:1.5'')';


--
-- Name: COLUMN evento_corporativo.descricao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.descricao IS 'Descrição detalhada do evento';


--
-- Name: COLUMN evento_corporativo.impacto_posicoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.impacto_posicoes IS 'Indica se as posições já foram ajustadas';


--
-- Name: COLUMN evento_corporativo.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.observacoes IS 'Observações adicionais sobre o evento';


--
-- Name: COLUMN evento_corporativo.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN evento_corporativo.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.evento_corporativo.updated_at IS 'Data da última atualização';


--
-- Name: feriado_mercado; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.feriado_mercado (
    id uuid NOT NULL,
    pais character varying(2) NOT NULL,
    mercado character varying(20),
    data_feriado date NOT NULL,
    tipo_feriado public.tipoferiado NOT NULL,
    nome character varying(200) NOT NULL,
    horario_fechamento time without time zone,
    recorrente boolean NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT feriado_nome_min_length CHECK ((length((nome)::text) >= 3)),
    CONSTRAINT feriado_pais_iso_format CHECK (((pais)::text ~* '^[A-Z]{2}$'::text))
);


ALTER TABLE public.feriado_mercado OWNER TO exitus;

--
-- Name: TABLE feriado_mercado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.feriado_mercado IS 'Tabela de feriados e dias sem pregão nos mercados';


--
-- Name: COLUMN feriado_mercado.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.id IS 'Identificador único do feriado';


--
-- Name: COLUMN feriado_mercado.pais; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.pais IS 'Código ISO do país (BR, US, etc.)';


--
-- Name: COLUMN feriado_mercado.mercado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.mercado IS 'Mercado/bolsa específica (B3, NYSE, NASDAQ, etc.) - NULL = todos';


--
-- Name: COLUMN feriado_mercado.data_feriado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.data_feriado IS 'Data do feriado';


--
-- Name: COLUMN feriado_mercado.tipo_feriado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.tipo_feriado IS 'Tipo do feriado';


--
-- Name: COLUMN feriado_mercado.nome; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.nome IS 'Nome do feriado';


--
-- Name: COLUMN feriado_mercado.horario_fechamento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.horario_fechamento IS 'Horário de fechamento antecipado (se aplicável)';


--
-- Name: COLUMN feriado_mercado.recorrente; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.recorrente IS 'Indica se é feriado anual fixo (sempre no mesmo dia/mês)';


--
-- Name: COLUMN feriado_mercado.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.observacoes IS 'Observações sobre o feriado';


--
-- Name: COLUMN feriado_mercado.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN feriado_mercado.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.feriado_mercado.updated_at IS 'Data da última atualização';


--
-- Name: fonte_dados; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.fonte_dados (
    id uuid NOT NULL,
    nome character varying(100) NOT NULL,
    tipo_fonte public.tipofontedados NOT NULL,
    url_base character varying(500),
    requer_autenticacao boolean NOT NULL,
    rate_limit character varying(50),
    ativa boolean NOT NULL,
    prioridade integer NOT NULL,
    ultima_consulta timestamp with time zone,
    total_consultas integer NOT NULL,
    total_erros integer NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT fonte_consultas_positivas CHECK ((total_consultas >= 0)),
    CONSTRAINT fonte_erros_positivos CHECK ((total_erros >= 0)),
    CONSTRAINT fonte_nome_min_length CHECK ((length((nome)::text) >= 2)),
    CONSTRAINT fonte_prioridade_positiva CHECK ((prioridade > 0))
);


ALTER TABLE public.fonte_dados OWNER TO exitus;

--
-- Name: TABLE fonte_dados; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.fonte_dados IS 'Tabela de fontes de dados externas (APIs, scrapers)';


--
-- Name: COLUMN fonte_dados.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.id IS 'Identificador único da fonte';


--
-- Name: COLUMN fonte_dados.nome; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.nome IS 'Nome da fonte de dados (ex: yfinance, Alpha Vantage)';


--
-- Name: COLUMN fonte_dados.tipo_fonte; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.tipo_fonte IS 'Tipo da fonte de dados';


--
-- Name: COLUMN fonte_dados.url_base; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.url_base IS 'URL base da API ou site';


--
-- Name: COLUMN fonte_dados.requer_autenticacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.requer_autenticacao IS 'Indica se requer chave API ou autenticação';


--
-- Name: COLUMN fonte_dados.rate_limit; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.rate_limit IS 'Limite de requisições (ex: ''5/minute'', ''500/day'')';


--
-- Name: COLUMN fonte_dados.ativa; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.ativa IS 'Indica se fonte está ativa';


--
-- Name: COLUMN fonte_dados.prioridade; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.prioridade IS 'Ordem de prioridade (1 = maior prioridade)';


--
-- Name: COLUMN fonte_dados.ultima_consulta; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.ultima_consulta IS 'Timestamp da última consulta bem-sucedida';


--
-- Name: COLUMN fonte_dados.total_consultas; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.total_consultas IS 'Total de consultas realizadas';


--
-- Name: COLUMN fonte_dados.total_erros; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.total_erros IS 'Total de erros encontrados';


--
-- Name: COLUMN fonte_dados.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.observacoes IS 'Observações sobre a fonte de dados';


--
-- Name: COLUMN fonte_dados.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN fonte_dados.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.fonte_dados.updated_at IS 'Data da última atualização';


--
-- Name: log_auditoria; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.log_auditoria (
    id uuid NOT NULL,
    usuario_id uuid,
    acao character varying(50) NOT NULL,
    entidade character varying(100),
    entidade_id uuid,
    dados_antes json,
    dados_depois json,
    ip_address character varying(45),
    user_agent character varying(500),
    "timestamp" timestamp with time zone NOT NULL,
    sucesso boolean NOT NULL,
    mensagem text,
    CONSTRAINT log_acao_min_length CHECK ((length((acao)::text) >= 3))
);


ALTER TABLE public.log_auditoria OWNER TO exitus;

--
-- Name: TABLE log_auditoria; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.log_auditoria IS 'Tabela de logs de auditoria para compliance';


--
-- Name: COLUMN log_auditoria.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.id IS 'Identificador único do log';


--
-- Name: COLUMN log_auditoria.usuario_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.usuario_id IS 'ID do usuário (NULL para ações anônimas)';


--
-- Name: COLUMN log_auditoria.acao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.acao IS 'Tipo de ação (LOGIN, LOGOUT, CREATE, UPDATE, DELETE, VIEW, EXPORT, etc.)';


--
-- Name: COLUMN log_auditoria.entidade; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.entidade IS 'Nome da entidade afetada (Usuario, Transacao, Posicao, etc.)';


--
-- Name: COLUMN log_auditoria.entidade_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.entidade_id IS 'ID do registro afetado';


--
-- Name: COLUMN log_auditoria.dados_antes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.dados_antes IS 'Estado anterior do registro (JSON)';


--
-- Name: COLUMN log_auditoria.dados_depois; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.dados_depois IS 'Estado posterior do registro (JSON)';


--
-- Name: COLUMN log_auditoria.ip_address; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.ip_address IS 'Endereço IP de origem';


--
-- Name: COLUMN log_auditoria.user_agent; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.user_agent IS 'User-Agent (navegador/cliente)';


--
-- Name: COLUMN log_auditoria."timestamp"; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria."timestamp" IS 'Data/hora da ação';


--
-- Name: COLUMN log_auditoria.sucesso; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.sucesso IS 'Indica se ação foi bem-sucedida';


--
-- Name: COLUMN log_auditoria.mensagem; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.log_auditoria.mensagem IS 'Mensagem de erro ou detalhes adicionais';


--
-- Name: movimentacao_caixa; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.movimentacao_caixa (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    corretora_id uuid NOT NULL,
    corretora_destino_id uuid,
    provento_id uuid,
    tipo_movimentacao public.tipomovimentacao NOT NULL,
    valor numeric(18,2) NOT NULL,
    moeda character varying(3) NOT NULL,
    data_movimentacao date NOT NULL,
    descricao text,
    comprovante character varying(200),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT movimentacao_moeda_iso_format CHECK (((moeda)::text ~* '^[A-Z]{3}$'::text)),
    CONSTRAINT movimentacao_valor_positivo CHECK ((valor > (0)::numeric))
);


ALTER TABLE public.movimentacao_caixa OWNER TO exitus;

--
-- Name: TABLE movimentacao_caixa; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.movimentacao_caixa IS 'Tabela de movimentações de caixa em corretoras';


--
-- Name: COLUMN movimentacao_caixa.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.id IS 'Identificador único da movimentação';


--
-- Name: COLUMN movimentacao_caixa.usuario_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.usuario_id IS 'ID do usuário';


--
-- Name: COLUMN movimentacao_caixa.corretora_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.corretora_id IS 'ID da corretora (origem)';


--
-- Name: COLUMN movimentacao_caixa.corretora_destino_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.corretora_destino_id IS 'ID da corretora destino (apenas para transferências)';


--
-- Name: COLUMN movimentacao_caixa.provento_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.provento_id IS 'ID do provento (apenas para crédito de provento)';


--
-- Name: COLUMN movimentacao_caixa.tipo_movimentacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.tipo_movimentacao IS 'Tipo da movimentação';


--
-- Name: COLUMN movimentacao_caixa.valor; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.valor IS 'Valor da movimentação';


--
-- Name: COLUMN movimentacao_caixa.moeda; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.moeda IS 'Código ISO 4217 da moeda (BRL, USD, EUR)';


--
-- Name: COLUMN movimentacao_caixa.data_movimentacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.data_movimentacao IS 'Data da movimentação';


--
-- Name: COLUMN movimentacao_caixa.descricao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.descricao IS 'Descrição da movimentação';


--
-- Name: COLUMN movimentacao_caixa.comprovante; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.comprovante IS 'Referência ao comprovante (número, hash, arquivo)';


--
-- Name: COLUMN movimentacao_caixa.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN movimentacao_caixa.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.movimentacao_caixa.updated_at IS 'Data da última atualização';


--
-- Name: parametros_macro; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.parametros_macro (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pais character varying(2) NOT NULL,
    mercado character varying(10) NOT NULL,
    taxa_livre_risco numeric(8,6) NOT NULL,
    crescimento_medio numeric(8,6) NOT NULL,
    custo_capital numeric(8,6) NOT NULL,
    inflacao_anual numeric(8,6) NOT NULL,
    cap_rate_fii numeric(8,6),
    ytm_rf numeric(8,6),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parametros_macro OWNER TO exitus;

--
-- Name: posicao; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.posicao (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    corretora_id uuid NOT NULL,
    ativo_id uuid NOT NULL,
    quantidade numeric(18,8) NOT NULL,
    preco_medio numeric(18,6) NOT NULL,
    custo_total numeric(18,2) NOT NULL,
    taxas_acumuladas numeric(18,2) NOT NULL,
    impostos_acumulados numeric(18,2) NOT NULL,
    valor_atual numeric(18,2),
    lucro_prejuizo_realizado numeric(18,2) NOT NULL,
    lucro_prejuizo_nao_realizado numeric(18,2),
    data_primeira_compra date,
    data_ultima_atualizacao timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT posicao_custo_total_positivo CHECK ((custo_total >= (0)::numeric)),
    CONSTRAINT posicao_impostos_positivos CHECK ((impostos_acumulados >= (0)::numeric)),
    CONSTRAINT posicao_preco_medio_positivo CHECK ((preco_medio >= (0)::numeric)),
    CONSTRAINT posicao_quantidade_positiva CHECK ((quantidade >= (0)::numeric)),
    CONSTRAINT posicao_taxas_positivas CHECK ((taxas_acumuladas >= (0)::numeric))
);


ALTER TABLE public.posicao OWNER TO exitus;

--
-- Name: TABLE posicao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.posicao IS 'Tabela de posições em carteira (holdings)';


--
-- Name: COLUMN posicao.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.id IS 'Identificador único da posição';


--
-- Name: COLUMN posicao.usuario_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.usuario_id IS 'ID do usuário proprietário';


--
-- Name: COLUMN posicao.corretora_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.corretora_id IS 'ID da corretora onde está a posição';


--
-- Name: COLUMN posicao.ativo_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.ativo_id IS 'ID do ativo';


--
-- Name: COLUMN posicao.quantidade; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.quantidade IS 'Quantidade de ativos (suporta fracionários)';


--
-- Name: COLUMN posicao.preco_medio; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.preco_medio IS 'Preço médio de aquisição';


--
-- Name: COLUMN posicao.custo_total; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.custo_total IS 'Custo total investido (quantidade * preço médio)';


--
-- Name: COLUMN posicao.taxas_acumuladas; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.taxas_acumuladas IS 'Taxas de corretagem e custódia acumuladas';


--
-- Name: COLUMN posicao.impostos_acumulados; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.impostos_acumulados IS 'Impostos pagos acumulados (IR, IOF, etc.)';


--
-- Name: COLUMN posicao.valor_atual; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.valor_atual IS 'Valor de mercado atual da posição';


--
-- Name: COLUMN posicao.lucro_prejuizo_realizado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.lucro_prejuizo_realizado IS 'Lucro/prejuízo realizado em vendas';


--
-- Name: COLUMN posicao.lucro_prejuizo_nao_realizado; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.lucro_prejuizo_nao_realizado IS 'Lucro/prejuízo não realizado (marcação a mercado)';


--
-- Name: COLUMN posicao.data_primeira_compra; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.data_primeira_compra IS 'Data da primeira aquisição deste ativo';


--
-- Name: COLUMN posicao.data_ultima_atualizacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.data_ultima_atualizacao IS 'Data da última atualização de valores';


--
-- Name: COLUMN posicao.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN posicao.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.posicao.updated_at IS 'Data da última atualização';


--
-- Name: projecoes_renda; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.projecoes_renda (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    usuario_id uuid NOT NULL,
    portfolio_id uuid,
    mes_ano character varying(7) NOT NULL,
    renda_dividendos_projetada numeric(18,2) DEFAULT 0 NOT NULL,
    renda_jcp_projetada numeric(18,2) DEFAULT 0 NOT NULL,
    renda_rendimentos_projetada numeric(18,2) DEFAULT 0 NOT NULL,
    renda_total_mes numeric(18,2) DEFAULT 0 NOT NULL,
    renda_anual_projetada numeric(18,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.projecoes_renda OWNER TO exitus;

--
-- Name: provento; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.provento (
    id uuid NOT NULL,
    ativo_id uuid NOT NULL,
    tipo_provento public.tipoprovento NOT NULL,
    valor_por_acao numeric(18,6) NOT NULL,
    quantidade_ativos numeric(18,8) NOT NULL,
    valor_bruto numeric(18,2) NOT NULL,
    imposto_retido numeric(18,2) NOT NULL,
    valor_liquido numeric(18,2) NOT NULL,
    data_com date NOT NULL,
    data_pagamento date NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT provento_data_pagamento_valida CHECK ((data_pagamento >= data_com)),
    CONSTRAINT provento_imposto_positivo CHECK ((imposto_retido >= (0)::numeric)),
    CONSTRAINT provento_liquido_menor_bruto CHECK ((valor_liquido <= valor_bruto)),
    CONSTRAINT provento_quantidade_positiva CHECK ((quantidade_ativos > (0)::numeric)),
    CONSTRAINT provento_valor_bruto_positivo CHECK ((valor_bruto > (0)::numeric)),
    CONSTRAINT provento_valor_liquido_positivo CHECK ((valor_liquido > (0)::numeric)),
    CONSTRAINT provento_valor_por_acao_positivo CHECK ((valor_por_acao > (0)::numeric))
);


ALTER TABLE public.provento OWNER TO exitus;

--
-- Name: TABLE provento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.provento IS 'Tabela de proventos recebidos (dividendos, JCP, rendimentos)';


--
-- Name: COLUMN provento.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.id IS 'Identificador único do provento';


--
-- Name: COLUMN provento.ativo_id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.ativo_id IS 'ID do ativo que pagou o provento';


--
-- Name: COLUMN provento.tipo_provento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.tipo_provento IS 'Tipo do provento (dividendo, JCP, rendimento, etc.)';


--
-- Name: COLUMN provento.valor_por_acao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.valor_por_acao IS 'Valor unitário por ativo';


--
-- Name: COLUMN provento.quantidade_ativos; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.quantidade_ativos IS 'Quantidade de ativos que geraram o provento';


--
-- Name: COLUMN provento.valor_bruto; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.valor_bruto IS 'Valor bruto recebido';


--
-- Name: COLUMN provento.imposto_retido; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.imposto_retido IS 'IR retido na fonte';


--
-- Name: COLUMN provento.valor_liquido; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.valor_liquido IS 'Valor líquido creditado';


--
-- Name: COLUMN provento.data_com; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.data_com IS 'Data COM (último dia para ter direito ao provento)';


--
-- Name: COLUMN provento.data_pagamento; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.data_pagamento IS 'Data efetiva do pagamento';


--
-- Name: COLUMN provento.observacoes; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.observacoes IS 'Observações sobre o provento';


--
-- Name: COLUMN provento.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN provento.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.provento.updated_at IS 'Data da última atualização';


--
-- Name: regra_fiscal; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.regra_fiscal (
    id uuid NOT NULL,
    pais character varying(2) NOT NULL,
    tipo_ativo character varying(20),
    tipo_operacao character varying(20),
    aliquota_ir numeric(6,4) NOT NULL,
    valor_isencao numeric(18,2),
    incide_sobre public.incidenciaimposto NOT NULL,
    descricao text NOT NULL,
    vigencia_inicio date NOT NULL,
    vigencia_fim date,
    ativa boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT regra_aliquota_valida CHECK (((aliquota_ir >= (0)::numeric) AND (aliquota_ir <= (100)::numeric))),
    CONSTRAINT regra_isencao_positiva CHECK (((valor_isencao IS NULL) OR (valor_isencao >= (0)::numeric))),
    CONSTRAINT regra_pais_iso_format CHECK (((pais)::text ~* '^[A-Z]{2}$'::text)),
    CONSTRAINT regra_vigencia_valida CHECK (((vigencia_fim IS NULL) OR (vigencia_fim >= vigencia_inicio)))
);


ALTER TABLE public.regra_fiscal OWNER TO exitus;

--
-- Name: TABLE regra_fiscal; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON TABLE public.regra_fiscal IS 'Tabela de regras tributárias por país e tipo de ativo';


--
-- Name: COLUMN regra_fiscal.id; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.id IS 'Identificador único da regra';


--
-- Name: COLUMN regra_fiscal.pais; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.pais IS 'Código ISO do país (BR, US, etc.)';


--
-- Name: COLUMN regra_fiscal.tipo_ativo; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.tipo_ativo IS 'Tipo de ativo (ACAO, FII, REIT, BOND, etc.) - NULL = todos';


--
-- Name: COLUMN regra_fiscal.tipo_operacao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.tipo_operacao IS 'Tipo de operação (COMPRA, VENDA, DAY_TRADE, SWING_TRADE) - NULL = todas';


--
-- Name: COLUMN regra_fiscal.aliquota_ir; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.aliquota_ir IS 'Alíquota de IR em % (ex: 15.0000 = 15%)';


--
-- Name: COLUMN regra_fiscal.valor_isencao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.valor_isencao IS 'Valor de isenção mensal (ex: R$ 20.000,00 no Brasil)';


--
-- Name: COLUMN regra_fiscal.incide_sobre; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.incide_sobre IS 'Sobre o que incide o imposto';


--
-- Name: COLUMN regra_fiscal.descricao; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.descricao IS 'Descrição detalhada da regra fiscal';


--
-- Name: COLUMN regra_fiscal.vigencia_inicio; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.vigencia_inicio IS 'Data de início da vigência da regra';


--
-- Name: COLUMN regra_fiscal.vigencia_fim; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.vigencia_fim IS 'Data de fim da vigência (NULL = vigente indefinidamente)';


--
-- Name: COLUMN regra_fiscal.ativa; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.ativa IS 'Indica se regra está ativa';


--
-- Name: COLUMN regra_fiscal.created_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.created_at IS 'Data de criação do registro';


--
-- Name: COLUMN regra_fiscal.updated_at; Type: COMMENT; Schema: public; Owner: exitus
--

COMMENT ON COLUMN public.regra_fiscal.updated_at IS 'Data da última atualização';


--
-- Name: relatorios_performance; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.relatorios_performance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    usuario_id uuid NOT NULL,
    portfolio_id uuid,
    periodo_inicio date NOT NULL,
    periodo_fim date NOT NULL,
    retorno_bruto_percentual numeric(10,4),
    retorno_liquido_percentual numeric(10,4),
    indice_sharpe numeric(10,4),
    max_drawdown_percentual numeric(10,4),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT relatorios_performance_check CHECK ((periodo_inicio <= periodo_fim))
);


ALTER TABLE public.relatorios_performance OWNER TO exitus;

--
-- Name: transacao; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.transacao (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    tipo public.tipotransacao NOT NULL,
    ativo_id uuid NOT NULL,
    corretora_id uuid NOT NULL,
    data_transacao timestamp with time zone NOT NULL,
    quantidade numeric(18,8) NOT NULL,
    preco_unitario numeric(18,6) NOT NULL,
    valor_total numeric(18,2) NOT NULL,
    taxa_corretagem numeric(18,2) NOT NULL,
    taxa_liquidacao numeric(18,2) NOT NULL,
    emolumentos numeric(18,2) NOT NULL,
    imposto numeric(18,2) NOT NULL,
    outros_custos numeric(18,2) NOT NULL,
    custos_totais numeric(18,2) NOT NULL,
    valor_liquido numeric(18,2) NOT NULL,
    observacoes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.transacao OWNER TO exitus;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: exitus
--

CREATE TABLE public.usuario (
    id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nome_completo character varying(200),
    ativo boolean NOT NULL,
    role public.userrole NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.usuario OWNER TO exitus;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.alembic_version (version_num) FROM stdin;
259add41e63e
\.


--
-- Data for Name: ativo; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.ativo (id, ticker, nome, tipo, classe, mercado, moeda, preco_atual, data_ultima_cotacao, dividend_yield, p_l, p_vp, roe, ativo, deslistado, data_deslistagem, observacoes, created_at, updated_at, preco_teto, beta) FROM stdin;
87ac8225-0956-4b04-9d8e-fb20910af804	ITUB4	Itaú Unibanco PN	ACAO	RENDA_VARIAVEL	BR	BRL	28.450000	\N	\N	\N	\N	\N	t	f	\N	Setor: Bancos	2025-12-01 14:40:20.681106+00	2025-12-01 14:40:20.681106+00	\N	\N
1e515bec-6cc0-411c-9b8c-14917c796368	BBDC4	Bradesco PN	ACAO	RENDA_VARIAVEL	BR	BRL	13.200000	\N	\N	\N	\N	\N	t	f	\N	Setor: Bancos	2025-12-01 14:40:20.681109+00	2025-12-01 14:40:20.68111+00	\N	\N
0deec67c-0ca0-48d7-bb32-a815497f506c	BBAS3	Banco do Brasil ON	ACAO	RENDA_VARIAVEL	BR	BRL	25.600000	\N	\N	\N	\N	\N	t	f	\N	Setor: Bancos	2025-12-01 14:40:20.681112+00	2025-12-01 14:40:20.681112+00	\N	\N
cfb88347-f421-4a04-adcd-c6bf21e1cd22	MGLU3	Magazine Luiza ON	ACAO	RENDA_VARIAVEL	BR	BRL	8.750000	\N	\N	\N	\N	\N	t	f	\N	Setor: Varejo	2025-12-01 14:40:20.681115+00	2025-12-01 14:40:20.681115+00	\N	\N
dfed2549-214a-472e-9f6d-17169d54d30d	WEGE3	WEG ON	ACAO	RENDA_VARIAVEL	BR	BRL	42.300000	\N	\N	\N	\N	\N	t	f	\N	Setor: Máquinas e Equipamentos	2025-12-01 14:40:20.681117+00	2025-12-01 14:40:20.681117+00	\N	\N
4bcc406e-7831-4923-9477-89c2a4731ab2	RENT3	Localiza ON	ACAO	RENDA_VARIAVEL	BR	BRL	56.900000	\N	\N	\N	\N	\N	t	f	\N	Setor: Locação de Veículos	2025-12-01 14:40:20.681119+00	2025-12-01 14:40:20.68112+00	\N	\N
4f53220f-7f99-490d-820a-5c7e1a23c480	RAIL3	Rumo ON	ACAO	RENDA_VARIAVEL	BR	BRL	18.450000	\N	\N	\N	\N	\N	t	f	\N	Setor: Transporte	2025-12-01 14:40:20.681122+00	2025-12-01 14:40:20.681122+00	\N	\N
9ad84d24-1725-4d23-9ad4-ddb32f8869a1	SUZB3	Suzano ON	ACAO	RENDA_VARIAVEL	BR	BRL	52.800000	\N	\N	\N	\N	\N	t	f	\N	Setor: Papel e Celulose	2025-12-01 14:40:20.681124+00	2025-12-01 14:40:20.681124+00	\N	\N
bdc084b6-14e3-4068-91b6-4940cb4a5023	KLBN11	Klabin Units	ACAO	RENDA_VARIAVEL	BR	BRL	22.150000	\N	\N	\N	\N	\N	t	f	\N	Setor: Papel e Celulose	2025-12-01 14:40:20.681127+00	2025-12-01 14:40:20.681127+00	\N	\N
ae8cb2b0-6aa6-45d0-adc7-16cd55e6c79e	ELET3	Eletrobras ON	ACAO	RENDA_VARIAVEL	BR	BRL	42.100000	\N	\N	\N	\N	\N	t	f	\N	Setor: Energia Elétrica	2025-12-01 14:40:20.681129+00	2025-12-01 14:40:20.681129+00	\N	\N
4f93d48e-0d6a-4a7f-97b4-014721b09969	CMIG4	Cemig PN	ACAO	RENDA_VARIAVEL	BR	BRL	10.850000	\N	\N	\N	\N	\N	t	f	\N	Setor: Energia Elétrica	2025-12-01 14:40:20.681133+00	2025-12-01 14:40:20.681133+00	\N	\N
5765bb47-a6f0-4cd0-9b86-46bd9f5e8c8b	CPLE6	Copel PNB	ACAO	RENDA_VARIAVEL	BR	BRL	8.950000	\N	\N	\N	\N	\N	t	f	\N	Setor: Energia Elétrica	2025-12-01 14:40:20.681135+00	2025-12-01 14:40:20.681136+00	\N	\N
3a4810a7-736e-4748-a922-fb4d0dfac8b8	ABEV3	Ambev ON	ACAO	RENDA_VARIAVEL	BR	BRL	11.200000	\N	\N	\N	\N	\N	t	f	\N	Setor: Bebidas	2025-12-01 14:40:20.681138+00	2025-12-01 14:40:20.681139+00	\N	\N
787df1e0-fb6c-419d-9db1-e40eeb8e6179	HGLG11	CSHG Logística FII	FII	RENDA_VARIAVEL	BR	BRL	152.300000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Logística	2025-12-01 14:40:20.681141+00	2025-12-01 14:40:20.681141+00	\N	\N
d1fb382b-6e04-47e4-9c37-a962ec872e68	VISC11	Vinci Shopping Centers FII	FII	RENDA_VARIAVEL	BR	BRL	105.800000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Shopping	2025-12-01 14:40:20.681143+00	2025-12-01 14:40:20.681144+00	\N	\N
5f19e852-0851-4357-94e3-41a8a320a871	BTLG11	BTG Pactual Logística FII	FII	RENDA_VARIAVEL	BR	BRL	102.700000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Logística	2025-12-01 14:40:20.68115+00	2025-12-01 14:40:20.68115+00	\N	\N
16989c21-28e2-4dce-9607-8926db9e2672	XPML11	XP Malls FII	FII	RENDA_VARIAVEL	BR	BRL	95.600000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Shopping	2025-12-01 14:40:20.681152+00	2025-12-01 14:40:20.681152+00	\N	\N
88168342-8c56-4fdc-9713-7e0caadc9ef7	MXRF11	Maxi Renda FII	FII	RENDA_VARIAVEL	BR	BRL	10.250000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Híbrido	2025-12-01 14:40:20.681155+00	2025-12-01 14:40:20.681155+00	\N	\N
acc05091-f495-44a2-ba65-ae09c8c8a298	TRXF11	TRX Real Estate FII	FII	RENDA_VARIAVEL	BR	BRL	95.300000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Lajes Corporativas	2025-12-01 14:40:20.681157+00	2025-12-01 14:40:20.681157+00	\N	\N
b48c4dec-62ca-410e-b3f7-087cbc0fa172	KNCR11	Kinea Rendimentos Imobiliários FII	FII	RENDA_VARIAVEL	BR	BRL	110.500000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Papel	2025-12-01 14:40:20.681159+00	2025-12-01 14:40:20.68116+00	\N	\N
ec4ca9cc-1779-472b-9706-5c45755a4d16	LVBI11	VBI Logístico FII	FII	RENDA_VARIAVEL	BR	BRL	98.200000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Logística	2025-12-01 14:40:20.681162+00	2025-12-01 14:40:20.681162+00	\N	\N
7a51e943-5420-4103-8e81-301dfea899dd	GGRC11	GGR Covepi Renda FII	FII	RENDA_VARIAVEL	BR	BRL	105.400000	\N	\N	\N	\N	\N	t	f	\N	Segmento: Lajes Corporativas	2025-12-01 14:40:20.681165+00	2025-12-01 14:40:20.681165+00	\N	\N
69870f88-f1bb-4b21-8194-0d18fee4b81b	AAPL	Apple Inc	ACAO	RENDA_VARIAVEL	US	USD	195.500000	\N	0.5000	32.50	45.20	147.5000	t	f	\N	\N	2025-12-02 15:00:01.26274+00	2025-12-02 15:00:01.262742+00	\N	\N
957bf5cd-a622-41a6-8cfd-f572e654da11	BTC	Bitcoin	CRIPTO	CRIPTO	CRIPTO	USD	43500.000000	\N	\N	\N	\N	\N	t	f	\N	\N	2025-12-02 15:00:01.294043+00	2025-12-02 15:00:01.294047+00	\N	\N
4cde7bd8-3a83-4537-bdb4-e78fe429c227	AAPL	Apple Inc	ACAO	RENDA_VARIAVEL	NYSE	USD	225.000000	\N	0.0050	\N	\N	\N	t	f	\N	\N	2025-12-03 20:09:47.234188+00	2025-12-03 20:09:47.23419+00	\N	\N
46d148cd-24e3-454a-a9d3-abb35f5be02f	LVMH	LVMH Moët Hennessy	ACAO	RENDA_VARIAVEL	EURONEXT	EUR	750.000000	\N	0.0180	\N	\N	\N	t	f	\N	\N	2025-12-03 20:09:47.271791+00	2025-12-03 20:09:47.271795+00	\N	\N
0103f083-addd-4960-9b2e-f090a89b9407	BTC-USD	Bitcoin USD	CRIPTO	RENDA_VARIAVEL	GLOBAL	USD	\N	\N	\N	\N	\N	\N	t	f	\N	\N	2025-12-08 18:28:04.058377+00	2025-12-08 18:28:04.058377+00	\N	\N
b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	KNRI11	Kinea Renda Imobiliária FII	FII	RENDA_VARIAVEL	BR	BRL	149.510000	2025-12-09 20:43:14.872381+00	9.8000	\N	\N	\N	t	f	\N	Segmento: Híbrido	2025-12-01 14:40:20.681146+00	2025-12-09 20:43:14.878957+00	\N	\N
16836286-2538-41bd-9896-f975721df9c0	PETR4	Petrobras PN	ACAO	RENDA_VARIAVEL	BR	BRL	31.850000	2025-12-09 20:43:15.032249+00	0.0000	0.00	\N	\N	t	f	\N	Setor: Petróleo e Gás	2025-12-01 14:40:20.681096+00	2025-12-09 20:43:15.03314+00	42.350000	0.9000
3af7860e-e74c-40d2-b1b2-e49e784e25ea	VALE3	Vale ON	ACAO	RENDA_VARIAVEL	BR	BRL	70.120000	2025-12-09 20:43:15.264334+00	8.2000	0.00	\N	\N	t	f	\N	Setor: Mineração	2025-12-01 14:40:20.681102+00	2025-12-09 20:43:15.265228+00	\N	\N
\.


--
-- Data for Name: auditoria_relatorios; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.auditoria_relatorios (id, usuario_id, tipo_relatorio, data_inicio, data_fim, filtros, resultado_json, timestamp_criacao, timestamp_download, formato_export, chave_api_auditoria, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: configuracoes_alertas; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.configuracoes_alertas (id, usuario_id, ativo_id, portfolio_id, nome, tipo_alerta, condicao_valor, condicao_operador, condicao_valor2, ativo, frequencia_notificacao, canais_entrega, timestamp_criacao, timestamp_ultimo_acionamento, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: corretora; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.corretora (id, usuario_id, nome, tipo, pais, moeda_padrao, saldo_atual, ativa, observacoes, created_at, updated_at) FROM stdin;
b5a6d786-ed76-4213-b819-45c6fdcd949d	09f8f28f-5ffc-4dff-8256-ab0cef3dd25d	Binance	EXCHANGE	US	USD	5000.00	t	Exchange de criptomoedas	2025-12-02 14:39:10.866109+00	2025-12-02 14:39:10.866112+00
1db3e577-55d9-4873-aff3-2710ab796f50	09f8f28f-5ffc-4dff-8256-ab0cef3dd25d	Avenue Securities	CORRETORA	US	USD	2500.75	t	\N	2025-12-02 14:39:10.900263+00	2025-12-02 14:39:10.900265+00
46228e06-200f-49b8-91b6-94ec70601e5c	09f8f28f-5ffc-4dff-8256-ab0cef3dd25d	XP Investimentos	CORRETORA	BR	BRL	15000.00	t	Saldo atualizado	2025-12-02 14:39:10.792426+00	2025-12-02 14:39:11.103585+00
c5c2bc9d-2dde-4d16-ad9b-868628a746d1	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	Clear Corretora	CORRETORA	BR	BRL	10000.00	t	Corretora criada pelo seed M7 para testes de projeção.	2025-12-09 19:34:06.97961+00	2025-12-09 19:34:06.979612+00
\.


--
-- Data for Name: evento_corporativo; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.evento_corporativo (id, ativo_id, ativo_novo_id, tipo_evento, data_evento, data_com, proporcao, descricao, impacto_posicoes, observacoes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feriado_mercado; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.feriado_mercado (id, pais, mercado, data_feriado, tipo_feriado, nome, horario_fechamento, recorrente, observacoes, created_at, updated_at) FROM stdin;
ef412b6a-8af8-4dcb-96e7-92bfe8caa457	BR	B3	2025-01-01	NACIONAL	Confraternização Universal	\N	t	\N	2025-12-01 14:40:20.740643+00	2025-12-01 14:40:20.740645+00
195d17d1-dc41-4f24-a4ac-b776f396bcb7	BR	B3	2025-03-03	NACIONAL	Carnaval	\N	f	\N	2025-12-01 14:40:20.740649+00	2025-12-01 14:40:20.74065+00
acb20f5e-81d4-40aa-b5d7-0b03bc3163fc	BR	B3	2025-03-04	NACIONAL	Carnaval (Quarta de Cinzas - meio período)	\N	f	\N	2025-12-01 14:40:20.740652+00	2025-12-01 14:40:20.740652+00
fb7c9120-eedb-4d4e-ab26-6dc4473c6c98	BR	B3	2025-04-18	NACIONAL	Sexta-feira Santa	\N	t	\N	2025-12-01 14:40:20.740654+00	2025-12-01 14:40:20.740654+00
48c0c74d-6329-405c-b85b-bfe5c2a258c3	BR	B3	2025-04-21	NACIONAL	Tiradentes	\N	t	\N	2025-12-01 14:40:20.740656+00	2025-12-01 14:40:20.740657+00
60a4ae44-42ca-4985-9fa1-e0a65a24b276	BR	B3	2025-05-01	NACIONAL	Dia do Trabalho	\N	t	\N	2025-12-01 14:40:20.740659+00	2025-12-01 14:40:20.740659+00
006b682c-3206-4efc-b3e5-5a742a70ebc2	BR	B3	2025-06-19	NACIONAL	Corpus Christi	\N	f	\N	2025-12-01 14:40:20.740661+00	2025-12-01 14:40:20.740661+00
aee541fc-da57-4ae7-92e6-23dd73c01afb	BR	B3	2025-09-07	NACIONAL	Independência do Brasil	\N	t	\N	2025-12-01 14:40:20.740663+00	2025-12-01 14:40:20.740663+00
10904290-0850-4e97-81de-11e3206a9de9	BR	B3	2025-10-12	NACIONAL	Nossa Senhora Aparecida	\N	t	\N	2025-12-01 14:40:20.740665+00	2025-12-01 14:40:20.740665+00
bdd99f3f-8a55-419a-815e-358a7653a25d	BR	B3	2025-11-02	NACIONAL	Finados	\N	t	\N	2025-12-01 14:40:20.740667+00	2025-12-01 14:40:20.740668+00
74f831c6-94e0-4b17-b385-0f16956ba594	BR	B3	2025-11-15	NACIONAL	Proclamação da República	\N	t	\N	2025-12-01 14:40:20.740669+00	2025-12-01 14:40:20.74067+00
807176a5-b99d-400d-9b37-3779eec2012d	BR	B3	2025-11-20	NACIONAL	Dia da Consciência Negra	\N	t	\N	2025-12-01 14:40:20.740672+00	2025-12-01 14:40:20.740672+00
afa7c876-f66c-4ae5-9914-e4e7b66ac2a1	BR	B3	2025-12-24	FECHAMENTO_ANTECIPADO	Véspera de Natal (meio período)	\N	f	\N	2025-12-01 14:40:20.740674+00	2025-12-01 14:40:20.740674+00
cd09a825-7d16-46c3-bd75-76ebc374d03a	BR	B3	2025-12-25	NACIONAL	Natal	\N	t	\N	2025-12-01 14:40:20.740676+00	2025-12-01 14:40:20.740676+00
5779203e-7863-461d-8e6b-60c9a2b58eaa	BR	B3	2025-12-31	FECHAMENTO_ANTECIPADO	Véspera de Ano Novo (meio período)	\N	f	\N	2025-12-01 14:40:20.740678+00	2025-12-01 14:40:20.740678+00
b7fb2237-02d3-495d-ba50-da60ec7557f4	BR	B3	2026-01-01	NACIONAL	Confraternização Universal	\N	t	\N	2025-12-01 14:40:20.74068+00	2025-12-01 14:40:20.740681+00
acc243c5-314b-4b0e-b0e4-ede4d53621a2	BR	B3	2026-02-16	NACIONAL	Carnaval	\N	f	\N	2025-12-01 14:40:20.740682+00	2025-12-01 14:40:20.740683+00
d48dbdd6-e639-4540-a96a-d52b36079444	BR	B3	2026-02-17	NACIONAL	Carnaval (Quarta de Cinzas - meio período)	\N	f	\N	2025-12-01 14:40:20.740687+00	2025-12-01 14:40:20.740687+00
e978aae1-97cb-482d-94d9-107bb1e414a1	BR	B3	2026-04-03	NACIONAL	Sexta-feira Santa	\N	t	\N	2025-12-01 14:40:20.740689+00	2025-12-01 14:40:20.740689+00
82539b9a-3c46-40de-ab84-0416f21548b1	BR	B3	2026-04-21	NACIONAL	Tiradentes	\N	t	\N	2025-12-01 14:40:20.740691+00	2025-12-01 14:40:20.740691+00
11f431de-76b6-42ef-9183-d56b534d7526	BR	B3	2026-05-01	NACIONAL	Dia do Trabalho	\N	t	\N	2025-12-01 14:40:20.740693+00	2025-12-01 14:40:20.740693+00
439f68f2-dfd4-455f-9782-b58ae0e10dee	BR	B3	2026-06-04	NACIONAL	Corpus Christi	\N	f	\N	2025-12-01 14:40:20.740695+00	2025-12-01 14:40:20.740695+00
c77b784a-6435-414b-a6cb-68e4d99b7b56	BR	B3	2026-09-07	NACIONAL	Independência do Brasil	\N	t	\N	2025-12-01 14:40:20.740697+00	2025-12-01 14:40:20.740698+00
e2f0fd1e-c12c-4ffe-af89-92551a905801	BR	B3	2026-10-12	NACIONAL	Nossa Senhora Aparecida	\N	t	\N	2025-12-01 14:40:20.740699+00	2025-12-01 14:40:20.7407+00
bc78c84e-e1c5-46a8-b5cd-7de51aa3bfcb	BR	B3	2026-11-02	NACIONAL	Finados	\N	t	\N	2025-12-01 14:40:20.740702+00	2025-12-01 14:40:20.740702+00
a3f9060e-a506-47a8-b7eb-5e38afa8a8a8	BR	B3	2026-11-15	NACIONAL	Proclamação da República	\N	t	\N	2025-12-01 14:40:20.740707+00	2025-12-01 14:40:20.740708+00
e432a732-6d1c-4f19-9619-f9a2f8faa020	BR	B3	2026-11-20	NACIONAL	Dia da Consciência Negra	\N	t	\N	2025-12-01 14:40:20.74071+00	2025-12-01 14:40:20.74071+00
98d3c0aa-3f61-4f90-b93a-e25bb04ad859	BR	B3	2026-12-24	FECHAMENTO_ANTECIPADO	Véspera de Natal (meio período)	\N	f	\N	2025-12-01 14:40:20.740712+00	2025-12-01 14:40:20.740712+00
33be522d-6c20-4661-bf5e-dbd473e67d9e	BR	B3	2026-12-25	NACIONAL	Natal	\N	t	\N	2025-12-01 14:40:20.740714+00	2025-12-01 14:40:20.740715+00
2ec52f33-6f67-4426-9c82-37e40005cc8d	BR	B3	2026-12-31	FECHAMENTO_ANTECIPADO	Véspera de Ano Novo (meio período)	\N	f	\N	2025-12-01 14:40:20.740717+00	2025-12-01 14:40:20.740717+00
\.


--
-- Data for Name: fonte_dados; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.fonte_dados (id, nome, tipo_fonte, url_base, requer_autenticacao, rate_limit, ativa, prioridade, ultima_consulta, total_consultas, total_erros, observacoes, created_at, updated_at) FROM stdin;
08119457-0bba-48e9-92f7-a0416310b3a2	yfinance	API	https://query1.finance.yahoo.com	f	2000/hour	t	1	\N	0	0	Biblioteca Python gratuita para Yahoo Finance. Boa cobertura global, incluindo B3.	2025-12-01 14:40:20.772238+00	2025-12-01 14:40:20.77224+00
624fcc51-0476-4659-ad78-a8f051dae452	brapi.dev	API	https://brapi.dev/api	f	100/minute	t	1	\N	0	0	API brasileira gratuita especializada em ativos da B3. Dados em tempo real.	2025-12-01 14:40:20.772243+00	2025-12-01 14:40:20.772244+00
5f6f1925-5d98-4b32-bccc-d49a565e837c	Alpha Vantage	API	https://www.alphavantage.co/query	t	5/minute	t	2	\N	0	0	API gratuita com chave. Limite de 5 requisições por minuto (plano free).	2025-12-01 14:40:20.772246+00	2025-12-01 14:40:20.772246+00
34ed366d-d6d8-4954-85f1-6935a2b66950	Finnhub	API	https://finnhub.io/api/v1	t	60/minute	t	2	\N	0	0	API com plano gratuito. Boa cobertura de mercados globais e notícias.	2025-12-01 14:40:20.772248+00	2025-12-01 14:40:20.772249+00
672c9061-7221-4f35-9703-d2b2cd989e29	IEX Cloud	API	https://cloud.iexapis.com/stable	t	50000/month	t	3	\N	0	0	API focada em mercado americano. Plano gratuito com limite mensal.	2025-12-01 14:40:20.772251+00	2025-12-01 14:40:20.772251+00
fc995d6e-ec1a-4909-a50a-d1595cd08d0f	Polygon.io	API	https://api.polygon.io	t	5/minute	f	4	\N	0	0	API premium com dados históricos detalhados. Desativada por padrão.	2025-12-01 14:40:20.772253+00	2025-12-01 14:40:20.772253+00
327825fc-117c-48a9-8c83-2302f26c0746	Manual	MANUAL	\N	f	\N	t	99	\N	0	0	Entrada manual de dados pelo usuário.	2025-12-01 14:40:20.772256+00	2025-12-01 14:40:20.772256+00
\.


--
-- Data for Name: log_auditoria; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.log_auditoria (id, usuario_id, acao, entidade, entidade_id, dados_antes, dados_depois, ip_address, user_agent, "timestamp", sucesso, mensagem) FROM stdin;
\.


--
-- Data for Name: movimentacao_caixa; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.movimentacao_caixa (id, usuario_id, corretora_id, corretora_destino_id, provento_id, tipo_movimentacao, valor, moeda, data_movimentacao, descricao, comprovante, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: parametros_macro; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.parametros_macro (id, pais, mercado, taxa_livre_risco, crescimento_medio, custo_capital, inflacao_anual, cap_rate_fii, ytm_rf, ativo, created_at, updated_at) FROM stdin;
a2514d2b-ee8d-473b-8348-26764098428a	BR	B3	0.105000	0.045000	0.125000	0.042000	0.085000	0.115000	t	2025-12-03 19:51:53.63942+00	2025-12-03 19:51:53.63942+00
a9e83385-b498-40a9-81f2-320443fa721b	US	NYSE	0.042000	0.025000	0.085000	0.022000	0.065000	0.045000	t	2025-12-03 19:51:53.63942+00	2025-12-03 19:51:53.63942+00
3bf5e012-068d-4879-87da-0f6a86478a7d	EU	Euronext	0.028000	0.018000	0.072000	0.020000	0.045000	0.032000	t	2025-12-03 19:51:53.63942+00	2025-12-03 19:51:53.63942+00
47f6188d-cd0d-4000-9f3a-0a95a52a97b1	JP	Tokyo	0.001500	0.012000	0.035000	0.015000	0.035000	0.018000	t	2025-12-03 19:51:53.63942+00	2025-12-03 19:51:53.63942+00
\.


--
-- Data for Name: posicao; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.posicao (id, usuario_id, corretora_id, ativo_id, quantidade, preco_medio, custo_total, taxas_acumuladas, impostos_acumulados, valor_atual, lucro_prejuizo_realizado, lucro_prejuizo_nao_realizado, data_primeira_compra, data_ultima_atualizacao, created_at, updated_at) FROM stdin;
fde0b8b0-e967-4e10-87e6-4e3fd68f05f1	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	16836286-2538-41bd-9896-f975721df9c0	100.00000000	35.070000	3507.00	7.00	0.00	\N	0.00	\N	2025-04-09	2025-12-09 19:39:39.208687+00	2025-12-09 19:39:39.209873+00	2025-12-09 19:39:39.209874+00
575d8806-f41f-4625-895d-d1169aefaafa	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	3af7860e-e74c-40d2-b1b2-e49e784e25ea	50.00000000	60.140000	3007.00	7.00	0.00	\N	0.00	\N	2025-02-09	2025-12-09 19:39:39.214595+00	2025-12-09 19:39:39.215319+00	2025-12-09 19:39:39.21532+00
4990b451-0dbd-4235-93e9-2a950b0758cf	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	30.00000000	150.233333	4507.00	7.00	0.00	\N	0.00	\N	2025-06-09	2025-12-09 19:39:39.217223+00	2025-12-09 19:39:39.217447+00	2025-12-09 19:39:39.217447+00
\.


--
-- Data for Name: projecoes_renda; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.projecoes_renda (id, usuario_id, portfolio_id, mes_ano, renda_dividendos_projetada, renda_jcp_projetada, renda_rendimentos_projetada, renda_total_mes, renda_anual_projetada, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: provento; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.provento (id, ativo_id, tipo_provento, valor_por_acao, quantidade_ativos, valor_bruto, imposto_retido, valor_liquido, data_com, data_pagamento, observacoes, created_at, updated_at) FROM stdin;
0950b7af-f4c8-4471-b8a2-938d0c5e8e44	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.500000	1.00000000	0.50	0.00	0.50	2025-12-02	2025-12-09	Dividendo mensal PETR4 M-0 - seed M7	2025-12-09 19:39:39.114284+00	2025-12-09 19:39:39.114286+00
fc12a9d4-f860-48b5-b944-cada00aa9d53	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.500000	1.00000000	0.50	0.00	0.50	2025-11-02	2025-11-09	Dividendo mensal PETR4 M-1 - seed M7	2025-12-09 19:39:39.119835+00	2025-12-09 19:39:39.119838+00
2768c5c1-28c7-4b66-b484-982e33f15cba	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.490000	1.00000000	0.49	0.00	0.49	2025-10-02	2025-10-09	Dividendo mensal PETR4 M-2 - seed M7	2025-12-09 19:39:39.122487+00	2025-12-09 19:39:39.122489+00
b8aa92ea-f932-4129-8a66-93b77b4084a6	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.490000	1.00000000	0.49	0.00	0.49	2025-09-02	2025-09-09	Dividendo mensal PETR4 M-3 - seed M7	2025-12-09 19:39:39.125498+00	2025-12-09 19:39:39.1255+00
9df7f75f-0de7-45e0-9ff7-357bbfbfdac8	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.480000	1.00000000	0.48	0.00	0.48	2025-08-02	2025-08-09	Dividendo mensal PETR4 M-4 - seed M7	2025-12-09 19:39:39.128124+00	2025-12-09 19:39:39.128126+00
ae86c7a4-58bc-428f-bcc1-b9ba79d0103d	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.480000	1.00000000	0.48	0.00	0.48	2025-07-02	2025-07-09	Dividendo mensal PETR4 M-5 - seed M7	2025-12-09 19:39:39.131435+00	2025-12-09 19:39:39.13144+00
f049b80d-39bb-4003-b5b3-7cb4597624c9	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.480000	1.00000000	0.48	0.00	0.48	2025-06-02	2025-06-09	Dividendo mensal PETR4 M-6 - seed M7	2025-12-09 19:39:39.13444+00	2025-12-09 19:39:39.134443+00
4e17a11e-5039-4543-8a97-75ca240fd95e	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.470000	1.00000000	0.47	0.00	0.47	2025-05-02	2025-05-09	Dividendo mensal PETR4 M-7 - seed M7	2025-12-09 19:39:39.136921+00	2025-12-09 19:39:39.136923+00
5b885cc4-41dd-4753-a598-afe1135e8e95	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.470000	1.00000000	0.47	0.00	0.47	2025-04-02	2025-04-09	Dividendo mensal PETR4 M-8 - seed M7	2025-12-09 19:39:39.139711+00	2025-12-09 19:39:39.139714+00
15c4e383-8a0e-4819-9eef-e21adbdc0ec9	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.460000	1.00000000	0.46	0.00	0.46	2025-03-02	2025-03-09	Dividendo mensal PETR4 M-9 - seed M7	2025-12-09 19:39:39.142605+00	2025-12-09 19:39:39.142607+00
a0889dfc-b8ab-4955-9e21-5d2e0dbc78da	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.460000	1.00000000	0.46	0.00	0.46	2025-02-02	2025-02-09	Dividendo mensal PETR4 M-10 - seed M7	2025-12-09 19:39:39.145256+00	2025-12-09 19:39:39.145259+00
a0e45acb-a998-46f3-8ad1-6d77c4ae8181	16836286-2538-41bd-9896-f975721df9c0	DIVIDENDO	0.450000	1.00000000	0.45	0.00	0.45	2025-01-02	2025-01-09	Dividendo mensal PETR4 M-11 - seed M7	2025-12-09 19:39:39.148527+00	2025-12-09 19:39:39.148529+00
73c95b64-3fc4-4985-a25a-70ded29266c3	3af7860e-e74c-40d2-b1b2-e49e784e25ea	DIVIDENDO	1.200000	1.00000000	1.20	0.00	1.20	2025-12-02	2025-12-09	Dividendo trimestral VALE3 Q-0 - seed M7	2025-12-09 19:39:39.152148+00	2025-12-09 19:39:39.15215+00
a88d4676-734a-4117-9884-48bbc5fd9287	3af7860e-e74c-40d2-b1b2-e49e784e25ea	DIVIDENDO	1.200000	1.00000000	1.20	0.00	1.20	2025-09-02	2025-09-09	Dividendo trimestral VALE3 Q-1 - seed M7	2025-12-09 19:39:39.154599+00	2025-12-09 19:39:39.154601+00
90c61acb-8799-4e6a-94be-539dfd4b2d61	3af7860e-e74c-40d2-b1b2-e49e784e25ea	DIVIDENDO	1.200000	1.00000000	1.20	0.00	1.20	2025-06-02	2025-06-09	Dividendo trimestral VALE3 Q-2 - seed M7	2025-12-09 19:39:39.157356+00	2025-12-09 19:39:39.157358+00
cc27bd19-01c9-4420-a42d-24e02fc0c633	3af7860e-e74c-40d2-b1b2-e49e784e25ea	DIVIDENDO	1.200000	1.00000000	1.20	0.00	1.20	2025-03-02	2025-03-09	Dividendo trimestral VALE3 Q-3 - seed M7	2025-12-09 19:39:39.159799+00	2025-12-09 19:39:39.159801+00
dae6d91f-741c-4724-918a-311b9b920219	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.170000	1.00000000	1.17	0.00	1.17	2025-12-02	2025-12-09	Rendimento KNRI11 M-0 - seed M7	2025-12-09 19:39:39.164017+00	2025-12-09 19:39:39.164019+00
8b2157a0-cd44-4077-a43e-d911229de56d	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.170000	1.00000000	1.17	0.00	1.17	2025-11-02	2025-11-09	Rendimento KNRI11 M-1 - seed M7	2025-12-09 19:39:39.166935+00	2025-12-09 19:39:39.166936+00
5ccbb39b-106a-4628-9288-9dae3976a74a	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.170000	1.00000000	1.17	0.00	1.17	2025-10-02	2025-10-09	Rendimento KNRI11 M-2 - seed M7	2025-12-09 19:39:39.169321+00	2025-12-09 19:39:39.169322+00
107206c4-53d9-42b1-aa26-7f0e45fc14ab	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-09-02	2025-09-09	Rendimento KNRI11 M-3 - seed M7	2025-12-09 19:39:39.172637+00	2025-12-09 19:39:39.172639+00
b6ae1fe9-aba6-4b2a-b166-ad6b8f634a75	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-08-02	2025-08-09	Rendimento KNRI11 M-4 - seed M7	2025-12-09 19:39:39.175009+00	2025-12-09 19:39:39.175011+00
023a32d1-271b-4a4d-8587-20ec0d301a41	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-07-02	2025-07-09	Rendimento KNRI11 M-5 - seed M7	2025-12-09 19:39:39.177366+00	2025-12-09 19:39:39.177368+00
397d9005-d06c-4d67-9727-e51fe5281cfe	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-06-02	2025-06-09	Rendimento KNRI11 M-6 - seed M7	2025-12-09 19:39:39.180565+00	2025-12-09 19:39:39.180567+00
56397005-e37a-4893-9491-434b1d02df89	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-05-02	2025-05-09	Rendimento KNRI11 M-7 - seed M7	2025-12-09 19:39:39.183205+00	2025-12-09 19:39:39.183208+00
9e602c2d-fc85-4c56-b261-096ad697fed8	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-04-02	2025-04-09	Rendimento KNRI11 M-8 - seed M7	2025-12-09 19:39:39.185674+00	2025-12-09 19:39:39.185677+00
5c451813-93f8-4121-9e3b-9abaf4c261a1	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.160000	1.00000000	1.16	0.00	1.16	2025-03-02	2025-03-09	Rendimento KNRI11 M-9 - seed M7	2025-12-09 19:39:39.188569+00	2025-12-09 19:39:39.188571+00
37e9ebed-0610-4cd8-8744-3e42e062b163	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.150000	1.00000000	1.15	0.00	1.15	2025-02-02	2025-02-09	Rendimento KNRI11 M-10 - seed M7	2025-12-09 19:39:39.191024+00	2025-12-09 19:39:39.191026+00
26605313-954c-4240-a751-cd5ea68f9a85	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	RENDIMENTO	1.150000	1.00000000	1.15	0.00	1.15	2025-01-02	2025-01-09	Rendimento KNRI11 M-11 - seed M7	2025-12-09 19:39:39.193089+00	2025-12-09 19:39:39.193092+00
\.


--
-- Data for Name: regra_fiscal; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.regra_fiscal (id, pais, tipo_ativo, tipo_operacao, aliquota_ir, valor_isencao, incide_sobre, descricao, vigencia_inicio, vigencia_fim, ativa, created_at, updated_at) FROM stdin;
881ed004-6665-4459-96d0-097639c7d0d4	BR	ACAO	SWING_TRADE	15.0000	20000.00	LUCRO	IR sobre ganho de capital em ações - Swing Trade. Isenção para vendas até R$ 20.000,00 por mês.	2024-01-01	\N	t	2025-12-01 14:40:20.70985+00	2025-12-01 14:40:20.709853+00
541ca12c-2698-4637-9735-034c111485c8	BR	ACAO	DAY_TRADE	20.0000	\N	LUCRO	IR sobre ganho de capital em Day Trade. SEM isenção, alíquota de 20%.	2024-01-01	\N	t	2025-12-01 14:40:20.709857+00	2025-12-01 14:40:20.709857+00
dad45709-3222-4319-a5ef-a361c6c5ab14	BR	FII	SWING_TRADE	20.0000	\N	LUCRO	IR sobre ganho de capital em FIIs. SEM isenção, alíquota de 20%.	2024-01-01	\N	t	2025-12-01 14:40:20.70986+00	2025-12-01 14:40:20.70986+00
f9fb9e58-29e2-4050-aa57-cc5517e9ec76	BR	\N	\N	15.0000	\N	PROVENTO	IR sobre JCP (Juros sobre Capital Próprio). Retido na fonte, alíquota de 15%.	2024-01-01	\N	t	2025-12-01 14:40:20.709862+00	2025-12-01 14:40:20.709863+00
e2f14fb7-018c-4305-9af9-9dd659a43e24	BR	FII	\N	0.0000	\N	PROVENTO	Rendimentos de FII são ISENTOS de IR para pessoa física (requisitos: FII com +50 cotistas, cotas negociadas em bolsa, investidor com <10% das cotas).	2024-01-01	\N	t	2025-12-01 14:40:20.709865+00	2025-12-01 14:40:20.709865+00
ad2e3d5e-3a17-4960-b657-e778219d87d4	BR	ACAO	\N	0.0000	\N	PROVENTO	Dividendos de ações são ISENTOS de IR para pessoa física no Brasil.	2024-01-01	\N	t	2025-12-01 14:40:20.709867+00	2025-12-01 14:40:20.709868+00
\.


--
-- Data for Name: relatorios_performance; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.relatorios_performance (id, usuario_id, portfolio_id, periodo_inicio, periodo_fim, retorno_bruto_percentual, retorno_liquido_percentual, indice_sharpe, max_drawdown_percentual, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transacao; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.transacao (id, usuario_id, tipo, ativo_id, corretora_id, data_transacao, quantidade, preco_unitario, valor_total, taxa_corretagem, taxa_liquidacao, emolumentos, imposto, outros_custos, custos_totais, valor_liquido, observacoes, created_at, updated_at) FROM stdin;
51d38bb0-5697-465d-8088-060b4267896e	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	COMPRA	16836286-2538-41bd-9896-f975721df9c0	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	2025-04-09 00:00:00+00	100.00000000	35.000000	3500.00	5.00	1.00	1.00	0.00	0.00	7.00	3507.00	Transação de compra criada pelo seed M7.	2025-12-09 19:37:45.97062+00	2025-12-09 19:37:45.970622+00
011f3061-9b26-46f3-964c-6196d78563d7	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	COMPRA	3af7860e-e74c-40d2-b1b2-e49e784e25ea	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	2025-02-09 00:00:00+00	50.00000000	60.000000	3000.00	5.00	1.00	1.00	0.00	0.00	7.00	3007.00	Transação de compra criada pelo seed M7.	2025-12-09 19:37:45.979348+00	2025-12-09 19:37:45.979352+00
7fe2cc82-4b8e-4e34-8280-461a8a1d52f2	783c2bfd-9e36-4cbd-a4fb-901afae9fad3	COMPRA	b8e4ccc8-3dfe-4a97-a8eb-e21a24c2e2ad	c5c2bc9d-2dde-4d16-ad9b-868628a746d1	2025-06-09 00:00:00+00	30.00000000	150.000000	4500.00	5.00	1.00	1.00	0.00	0.00	7.00	4507.00	Transação de compra criada pelo seed M7.	2025-12-09 19:37:45.982344+00	2025-12-09 19:37:45.982347+00
\.


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: exitus
--

COPY public.usuario (id, username, email, password_hash, nome_completo, ativo, role, created_at, updated_at) FROM stdin;
783c2bfd-9e36-4cbd-a4fb-901afae9fad3	admin	admin@exitus.com	scrypt:32768:8:1$wHXH5C7em81p92Dj$5edd17f1109d04cba7f80f0a6df2b7ec5c539f3bb8db55a706d7d72f694f35d5f2bdb69821e0b8a12a8061f81ba5bb9c836f75fcb0bdadd0d990314b0348da17	Administrador do Sistema	t	ADMIN	2025-12-01 14:40:20.639694+00	2025-12-01 14:40:20.639696+00
d40de14b-1079-4f7b-9162-94ded563e65d	maria.santos	maria.santos@example.com	scrypt:32768:8:1$uhH7Xw5vNOotspjm$64d409d19cda810c6c2b42808aab0b47296d1f3ea4150cb6761cfae4d8deec7895eb3ed9a1713bd5e9a49bc776fa4ce7b9e69bf9932f1b87a04680c28d50c831	Maria Santos	t	USER	2025-12-01 14:40:20.639704+00	2025-12-01 14:40:20.639705+00
8d11c310-fa71-4b1b-b2c9-13331563803f	viewer	viewer@exitus.com	scrypt:32768:8:1$vxC0fkGD7ampYFPX$b4d0428740aec2724b1c7f1ccaf58c9aac0c7756303f6f4f81e7edd9084eb279746eef1bac37fab3df33964869091f32901fd68891f77d3f19d827033fdf77ed	Usuário Visualizador	t	READONLY	2025-12-01 14:40:20.639711+00	2025-12-01 14:40:20.639712+00
1f977dd3-c810-49af-a896-4862dbb375e0	teste.user	teste@exitus.com	scrypt:32768:8:1$VlIcu8QiOL9i1IX9$6a1d49081e7dd939b48f4e5d22c0da68077932fab782869efd28ccfa8987cbb0d33ce623843a975461cf1076668c58abba375d2d831ff56d68ee496b36e002ac	Usuário de Teste	t	USER	2025-12-02 14:32:30.74402+00	2025-12-02 14:32:30.744022+00
09f8f28f-5ffc-4dff-8256-ab0cef3dd25d	joao.silva	joao.silva@example.com	scrypt:32768:8:1$5uImncAkVtmVNKZU$f69ee9d02846bd49ed7bf68d0dd404024e63354ff0216b2aa054ee610592e9c21a34fa3470b0332c10cda2ecfb4dd9bc4b9a8a2212c186b3277768cf0ed2b443	João Silva Atualizado	t	USER	2025-12-01 14:40:20.6397+00	2025-12-02 14:32:31.360123+00
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: ativo ativo_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.ativo
    ADD CONSTRAINT ativo_pkey PRIMARY KEY (id);


--
-- Name: auditoria_relatorios auditoria_relatorios_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.auditoria_relatorios
    ADD CONSTRAINT auditoria_relatorios_pkey PRIMARY KEY (id);


--
-- Name: configuracoes_alertas configuracoes_alertas_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.configuracoes_alertas
    ADD CONSTRAINT configuracoes_alertas_pkey PRIMARY KEY (id);


--
-- Name: corretora corretora_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.corretora
    ADD CONSTRAINT corretora_pkey PRIMARY KEY (id);


--
-- Name: evento_corporativo evento_corporativo_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.evento_corporativo
    ADD CONSTRAINT evento_corporativo_pkey PRIMARY KEY (id);


--
-- Name: feriado_mercado feriado_mercado_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.feriado_mercado
    ADD CONSTRAINT feriado_mercado_pkey PRIMARY KEY (id);


--
-- Name: fonte_dados fonte_dados_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.fonte_dados
    ADD CONSTRAINT fonte_dados_pkey PRIMARY KEY (id);


--
-- Name: log_auditoria log_auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.log_auditoria
    ADD CONSTRAINT log_auditoria_pkey PRIMARY KEY (id);


--
-- Name: movimentacao_caixa movimentacao_caixa_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.movimentacao_caixa
    ADD CONSTRAINT movimentacao_caixa_pkey PRIMARY KEY (id);


--
-- Name: parametros_macro parametros_macro_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.parametros_macro
    ADD CONSTRAINT parametros_macro_pkey PRIMARY KEY (id);


--
-- Name: posicao posicao_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.posicao
    ADD CONSTRAINT posicao_pkey PRIMARY KEY (id);


--
-- Name: projecoes_renda projecoes_renda_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.projecoes_renda
    ADD CONSTRAINT projecoes_renda_pkey PRIMARY KEY (id);


--
-- Name: projecoes_renda projecoes_renda_usuario_id_portfolio_id_mes_ano_key; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.projecoes_renda
    ADD CONSTRAINT projecoes_renda_usuario_id_portfolio_id_mes_ano_key UNIQUE (usuario_id, portfolio_id, mes_ano);


--
-- Name: provento provento_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.provento
    ADD CONSTRAINT provento_pkey PRIMARY KEY (id);


--
-- Name: regra_fiscal regra_fiscal_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.regra_fiscal
    ADD CONSTRAINT regra_fiscal_pkey PRIMARY KEY (id);


--
-- Name: relatorios_performance relatorios_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.relatorios_performance
    ADD CONSTRAINT relatorios_performance_pkey PRIMARY KEY (id);


--
-- Name: transacao transacao_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_pkey PRIMARY KEY (id);


--
-- Name: ativo unique_ativo_ticker_mercado; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.ativo
    ADD CONSTRAINT unique_ativo_ticker_mercado UNIQUE (ticker, mercado);


--
-- Name: corretora unique_corretora_usuario_nome_pais; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.corretora
    ADD CONSTRAINT unique_corretora_usuario_nome_pais UNIQUE (usuario_id, nome, pais);


--
-- Name: feriado_mercado unique_feriado_pais_mercado_data; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.feriado_mercado
    ADD CONSTRAINT unique_feriado_pais_mercado_data UNIQUE (pais, mercado, data_feriado);


--
-- Name: posicao unique_posicao_usuario_corretora_ativo; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.posicao
    ADD CONSTRAINT unique_posicao_usuario_corretora_ativo UNIQUE (usuario_id, corretora_id, ativo_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: ix_ativo_ativo; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_ativo ON public.ativo USING btree (ativo);


--
-- Name: ix_ativo_classe; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_classe ON public.ativo USING btree (classe);


--
-- Name: ix_ativo_data_ultima_cotacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_data_ultima_cotacao ON public.ativo USING btree (data_ultima_cotacao);


--
-- Name: ix_ativo_deslistado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_deslistado ON public.ativo USING btree (deslistado);


--
-- Name: ix_ativo_mercado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_mercado ON public.ativo USING btree (mercado);


--
-- Name: ix_ativo_moeda; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_moeda ON public.ativo USING btree (moeda);


--
-- Name: ix_ativo_nome; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_nome ON public.ativo USING btree (nome);


--
-- Name: ix_ativo_ticker; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_ticker ON public.ativo USING btree (ticker);


--
-- Name: ix_ativo_tipo; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_ativo_tipo ON public.ativo USING btree (tipo);


--
-- Name: ix_auditoria_relatorios_timestamp_criacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_auditoria_relatorios_timestamp_criacao ON public.auditoria_relatorios USING btree (timestamp_criacao);


--
-- Name: ix_auditoria_relatorios_tipo_relatorio; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_auditoria_relatorios_tipo_relatorio ON public.auditoria_relatorios USING btree (tipo_relatorio);


--
-- Name: ix_auditoria_relatorios_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_auditoria_relatorios_usuario_id ON public.auditoria_relatorios USING btree (usuario_id);


--
-- Name: ix_configuracoes_alertas_ativo_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_configuracoes_alertas_ativo_id ON public.configuracoes_alertas USING btree (ativo_id);


--
-- Name: ix_configuracoes_alertas_tipo_alerta; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_configuracoes_alertas_tipo_alerta ON public.configuracoes_alertas USING btree (tipo_alerta);


--
-- Name: ix_configuracoes_alertas_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_configuracoes_alertas_usuario_id ON public.configuracoes_alertas USING btree (usuario_id);


--
-- Name: ix_corretora_ativa; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_ativa ON public.corretora USING btree (ativa);


--
-- Name: ix_corretora_moeda_padrao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_moeda_padrao ON public.corretora USING btree (moeda_padrao);


--
-- Name: ix_corretora_nome; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_nome ON public.corretora USING btree (nome);


--
-- Name: ix_corretora_pais; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_pais ON public.corretora USING btree (pais);


--
-- Name: ix_corretora_tipo; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_tipo ON public.corretora USING btree (tipo);


--
-- Name: ix_corretora_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_corretora_usuario_id ON public.corretora USING btree (usuario_id);


--
-- Name: ix_evento_corporativo_ativo_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_ativo_id ON public.evento_corporativo USING btree (ativo_id);


--
-- Name: ix_evento_corporativo_ativo_novo_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_ativo_novo_id ON public.evento_corporativo USING btree (ativo_novo_id);


--
-- Name: ix_evento_corporativo_data_com; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_data_com ON public.evento_corporativo USING btree (data_com);


--
-- Name: ix_evento_corporativo_data_evento; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_data_evento ON public.evento_corporativo USING btree (data_evento);


--
-- Name: ix_evento_corporativo_impacto_posicoes; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_impacto_posicoes ON public.evento_corporativo USING btree (impacto_posicoes);


--
-- Name: ix_evento_corporativo_tipo_evento; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_evento_corporativo_tipo_evento ON public.evento_corporativo USING btree (tipo_evento);


--
-- Name: ix_feriado_mercado_data_feriado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_feriado_mercado_data_feriado ON public.feriado_mercado USING btree (data_feriado);


--
-- Name: ix_feriado_mercado_mercado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_feriado_mercado_mercado ON public.feriado_mercado USING btree (mercado);


--
-- Name: ix_feriado_mercado_pais; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_feriado_mercado_pais ON public.feriado_mercado USING btree (pais);


--
-- Name: ix_feriado_mercado_recorrente; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_feriado_mercado_recorrente ON public.feriado_mercado USING btree (recorrente);


--
-- Name: ix_feriado_mercado_tipo_feriado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_feriado_mercado_tipo_feriado ON public.feriado_mercado USING btree (tipo_feriado);


--
-- Name: ix_fonte_dados_ativa; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_fonte_dados_ativa ON public.fonte_dados USING btree (ativa);


--
-- Name: ix_fonte_dados_nome; Type: INDEX; Schema: public; Owner: exitus
--

CREATE UNIQUE INDEX ix_fonte_dados_nome ON public.fonte_dados USING btree (nome);


--
-- Name: ix_fonte_dados_prioridade; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_fonte_dados_prioridade ON public.fonte_dados USING btree (prioridade);


--
-- Name: ix_fonte_dados_tipo_fonte; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_fonte_dados_tipo_fonte ON public.fonte_dados USING btree (tipo_fonte);


--
-- Name: ix_fonte_dados_ultima_consulta; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_fonte_dados_ultima_consulta ON public.fonte_dados USING btree (ultima_consulta);


--
-- Name: ix_log_auditoria_acao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_acao ON public.log_auditoria USING btree (acao);


--
-- Name: ix_log_auditoria_entidade; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_entidade ON public.log_auditoria USING btree (entidade);


--
-- Name: ix_log_auditoria_entidade_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_entidade_id ON public.log_auditoria USING btree (entidade_id);


--
-- Name: ix_log_auditoria_ip_address; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_ip_address ON public.log_auditoria USING btree (ip_address);


--
-- Name: ix_log_auditoria_sucesso; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_sucesso ON public.log_auditoria USING btree (sucesso);


--
-- Name: ix_log_auditoria_timestamp; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_timestamp ON public.log_auditoria USING btree ("timestamp");


--
-- Name: ix_log_auditoria_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_log_auditoria_usuario_id ON public.log_auditoria USING btree (usuario_id);


--
-- Name: ix_movimentacao_caixa_corretora_destino_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_corretora_destino_id ON public.movimentacao_caixa USING btree (corretora_destino_id);


--
-- Name: ix_movimentacao_caixa_corretora_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_corretora_id ON public.movimentacao_caixa USING btree (corretora_id);


--
-- Name: ix_movimentacao_caixa_data_movimentacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_data_movimentacao ON public.movimentacao_caixa USING btree (data_movimentacao);


--
-- Name: ix_movimentacao_caixa_moeda; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_moeda ON public.movimentacao_caixa USING btree (moeda);


--
-- Name: ix_movimentacao_caixa_provento_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_provento_id ON public.movimentacao_caixa USING btree (provento_id);


--
-- Name: ix_movimentacao_caixa_tipo_movimentacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_tipo_movimentacao ON public.movimentacao_caixa USING btree (tipo_movimentacao);


--
-- Name: ix_movimentacao_caixa_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_movimentacao_caixa_usuario_id ON public.movimentacao_caixa USING btree (usuario_id);


--
-- Name: ix_parametros_macro_ativo; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_parametros_macro_ativo ON public.parametros_macro USING btree (ativo);


--
-- Name: ix_parametros_macro_mercado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_parametros_macro_mercado ON public.parametros_macro USING btree (mercado);


--
-- Name: ix_parametros_macro_pais; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_parametros_macro_pais ON public.parametros_macro USING btree (pais);


--
-- Name: ix_parametros_macro_pais_mercado; Type: INDEX; Schema: public; Owner: exitus
--

CREATE UNIQUE INDEX ix_parametros_macro_pais_mercado ON public.parametros_macro USING btree (pais, mercado);


--
-- Name: ix_posicao_ativo_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_posicao_ativo_id ON public.posicao USING btree (ativo_id);


--
-- Name: ix_posicao_corretora_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_posicao_corretora_id ON public.posicao USING btree (corretora_id);


--
-- Name: ix_posicao_data_primeira_compra; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_posicao_data_primeira_compra ON public.posicao USING btree (data_primeira_compra);


--
-- Name: ix_posicao_data_ultima_atualizacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_posicao_data_ultima_atualizacao ON public.posicao USING btree (data_ultima_atualizacao);


--
-- Name: ix_posicao_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_posicao_usuario_id ON public.posicao USING btree (usuario_id);


--
-- Name: ix_projecoes_renda_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_projecoes_renda_usuario_id ON public.projecoes_renda USING btree (usuario_id);


--
-- Name: ix_provento_ativo_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_provento_ativo_id ON public.provento USING btree (ativo_id);


--
-- Name: ix_provento_data_com; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_provento_data_com ON public.provento USING btree (data_com);


--
-- Name: ix_provento_data_pagamento; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_provento_data_pagamento ON public.provento USING btree (data_pagamento);


--
-- Name: ix_provento_tipo_provento; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_provento_tipo_provento ON public.provento USING btree (tipo_provento);


--
-- Name: ix_regra_fiscal_ativa; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_ativa ON public.regra_fiscal USING btree (ativa);


--
-- Name: ix_regra_fiscal_incide_sobre; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_incide_sobre ON public.regra_fiscal USING btree (incide_sobre);


--
-- Name: ix_regra_fiscal_pais; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_pais ON public.regra_fiscal USING btree (pais);


--
-- Name: ix_regra_fiscal_tipo_ativo; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_tipo_ativo ON public.regra_fiscal USING btree (tipo_ativo);


--
-- Name: ix_regra_fiscal_tipo_operacao; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_tipo_operacao ON public.regra_fiscal USING btree (tipo_operacao);


--
-- Name: ix_regra_fiscal_vigencia_fim; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_vigencia_fim ON public.regra_fiscal USING btree (vigencia_fim);


--
-- Name: ix_regra_fiscal_vigencia_inicio; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_regra_fiscal_vigencia_inicio ON public.regra_fiscal USING btree (vigencia_inicio);


--
-- Name: ix_relatorios_performance_usuario_id; Type: INDEX; Schema: public; Owner: exitus
--

CREATE INDEX ix_relatorios_performance_usuario_id ON public.relatorios_performance USING btree (usuario_id);


--
-- Name: ix_usuario_email; Type: INDEX; Schema: public; Owner: exitus
--

CREATE UNIQUE INDEX ix_usuario_email ON public.usuario USING btree (email);


--
-- Name: ix_usuario_username; Type: INDEX; Schema: public; Owner: exitus
--

CREATE UNIQUE INDEX ix_usuario_username ON public.usuario USING btree (username);


--
-- Name: auditoria_relatorios auditoria_relatorios_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.auditoria_relatorios
    ADD CONSTRAINT auditoria_relatorios_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: configuracoes_alertas configuracoes_alertas_ativo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.configuracoes_alertas
    ADD CONSTRAINT configuracoes_alertas_ativo_id_fkey FOREIGN KEY (ativo_id) REFERENCES public.ativo(id) ON DELETE CASCADE;


--
-- Name: configuracoes_alertas configuracoes_alertas_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.configuracoes_alertas
    ADD CONSTRAINT configuracoes_alertas_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: corretora corretora_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.corretora
    ADD CONSTRAINT corretora_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: evento_corporativo evento_corporativo_ativo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.evento_corporativo
    ADD CONSTRAINT evento_corporativo_ativo_id_fkey FOREIGN KEY (ativo_id) REFERENCES public.ativo(id) ON DELETE RESTRICT;


--
-- Name: evento_corporativo evento_corporativo_ativo_novo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.evento_corporativo
    ADD CONSTRAINT evento_corporativo_ativo_novo_id_fkey FOREIGN KEY (ativo_novo_id) REFERENCES public.ativo(id) ON DELETE SET NULL;


--
-- Name: log_auditoria log_auditoria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.log_auditoria
    ADD CONSTRAINT log_auditoria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE SET NULL;


--
-- Name: movimentacao_caixa movimentacao_caixa_corretora_destino_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.movimentacao_caixa
    ADD CONSTRAINT movimentacao_caixa_corretora_destino_id_fkey FOREIGN KEY (corretora_destino_id) REFERENCES public.corretora(id) ON DELETE SET NULL;


--
-- Name: movimentacao_caixa movimentacao_caixa_corretora_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.movimentacao_caixa
    ADD CONSTRAINT movimentacao_caixa_corretora_id_fkey FOREIGN KEY (corretora_id) REFERENCES public.corretora(id) ON DELETE CASCADE;


--
-- Name: movimentacao_caixa movimentacao_caixa_provento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.movimentacao_caixa
    ADD CONSTRAINT movimentacao_caixa_provento_id_fkey FOREIGN KEY (provento_id) REFERENCES public.provento(id) ON DELETE SET NULL;


--
-- Name: movimentacao_caixa movimentacao_caixa_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.movimentacao_caixa
    ADD CONSTRAINT movimentacao_caixa_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: posicao posicao_ativo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.posicao
    ADD CONSTRAINT posicao_ativo_id_fkey FOREIGN KEY (ativo_id) REFERENCES public.ativo(id) ON DELETE RESTRICT;


--
-- Name: posicao posicao_corretora_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.posicao
    ADD CONSTRAINT posicao_corretora_id_fkey FOREIGN KEY (corretora_id) REFERENCES public.corretora(id) ON DELETE CASCADE;


--
-- Name: posicao posicao_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.posicao
    ADD CONSTRAINT posicao_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: projecoes_renda projecoes_renda_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.projecoes_renda
    ADD CONSTRAINT projecoes_renda_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: provento provento_ativo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.provento
    ADD CONSTRAINT provento_ativo_id_fkey FOREIGN KEY (ativo_id) REFERENCES public.ativo(id) ON DELETE RESTRICT;


--
-- Name: relatorios_performance relatorios_performance_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.relatorios_performance
    ADD CONSTRAINT relatorios_performance_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id) ON DELETE CASCADE;


--
-- Name: transacao transacao_ativo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_ativo_id_fkey FOREIGN KEY (ativo_id) REFERENCES public.ativo(id);


--
-- Name: transacao transacao_corretora_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_corretora_id_fkey FOREIGN KEY (corretora_id) REFERENCES public.corretora(id);


--
-- Name: transacao transacao_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: exitus
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- PostgreSQL database dump complete
--

\unrestrict yJrdMaalVNGLlAnGpPFtoVAB9G9pBU4MbtcNfQ3Pkhvb18K2YglZjBuiENJzCiC

